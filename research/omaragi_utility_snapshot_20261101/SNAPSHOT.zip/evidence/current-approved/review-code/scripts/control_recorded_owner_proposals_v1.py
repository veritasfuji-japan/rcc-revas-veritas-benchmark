"""Replay actual final tool proposals through both equally scoped gates.

Pure governance control using explicit TEST enrollment fixtures. No generation,
new paid calls, official scores, or reuse of live-model payment grants.
"""
from datetime import datetime,timezone
import json
from pathlib import Path
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'benchmark'),str(ROOT/'agentdojo/src'),str(ROOT/'veritas-v13'),str(ROOT/'rcc-v13/external-eval/v0.3.9/src')]


def offline(event,args):
    if event in {'socket.connect','socket.connect_ex','socket.getaddrinfo'}:raise RuntimeError('OFFLINE_RECORDED_PROPOSAL_CONTROL')


sys.addaudithook(offline)
from agentdojo.task_suite.load_suites import get_suite
from owner_approved_research_runtime_v1 import OwnerEnrollment,ScopeSession,make_owner_runtime
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import load_rcc_gate,verify_authority_fixture,sha_json


def main():
    selected=Path(json.loads((ROOT/'LATEST_MINI_SUPPORT_V1.json').read_text())['directory'])
    assert (selected/'final-lock.json').exists()
    records=[json.loads(x) for x in (selected/'execution_records.jsonl').read_text().splitlines()]
    proposal=json.loads((ROOT/'RESEARCH_APPROVAL_PROPOSAL.json').read_text())
    scopes={s['case_id']:s for s in proposal['proposed_scopes']}
    records=[r for r in records if r['case_id'] in scopes]
    assert len(records)==80
    suite=get_suite('v1.2.2','banking');gate=load_rcc_gate(ROOT/'rcc-v13');actor=verify_authority_fixture()
    fields=('authority_check_result','constraint_check_result','risk_check_result','drift_check_result','failed_predicates','missing_predicates','final_outcome')
    results=[];step_count=0;native_pairs=0
    for record in records:
        with tempfile.TemporaryDirectory() as temporary:
            enrollment=OwnerEnrollment('mini-support-v1',proposal['proposed_scopes'],
                {'owner_review_approved':True,'decision_source':{'source_record_sha256':'TEST_ONLY_RECORDED_PROPOSAL_CONTROL'}},
                Path(temporary)/'test.sqlite',clock=lambda:datetime(2026,11,1,20,tzinfo=timezone.utc),test_only=True)
            cid=record['case_id'];tid=int(cid.split(':')[1].rsplit('_',1)[1]);pair={}
            for arm in ('B_SUPPORT','E_SUPPORT'):
                env=suite.environment_type.model_validate(record['pre_environment']);journal=[]
                session=ScopeSession(enrollment,cid,arm,record['original_request'],record['pre_environment'])
                runtime=make_owner_runtime(gate,tid,cid,record['original_request'],journal,actor,session)(suite.tools)
                steps=[]
                for call in record['functions_stack_trace']:
                    before=sha_json(env.model_dump(mode='json'));start=len(journal)
                    _,error=runtime.run_function(env,call['function'],call['args'])
                    native=[e['payload'] for e in journal[start:] if e['event']=='VERITAS_BIND_RECEIPT']
                    steps.append({'function':call['function'],'args_sha256':sha_json(call['args']),
                        'pre_state_sha256':before,'post_state_sha256':sha_json(env.model_dump(mode='json')),
                        'native_checks':[{k:e['receipt'].get(k) for k in fields} for e in native],
                        'candidate_hashes':[e['candidate_sha256'] for e in native]})
                assert sha_json(env.model_dump(mode='json'))==record['post_state_sha256'],('ACTUAL_TRAJECTORY_EFFECT_MISMATCH',cid,record['arm'],arm)
                pair[arm]=steps
            assert pair['B_SUPPORT']==pair['E_SUPPORT'],('GOVERNANCE_ARM_DIFFERENCE',cid,record['arm'])
            step_count+=len(pair['B_SUPPORT']);native_pairs+=sum(len(s['native_checks']) for s in pair['B_SUPPORT'])
            results.append({'case_id':cid,'recorded_source_arm':record['arm'],
                'actual_record_post_state_sha256':record['post_state_sha256'],'both_replays_match_actual_poststate':True,
                'same_candidates_prestates_native_checks_and_effects':True,'steps':pair['B_SUPPORT']})
    dest=ROOT/'recorded-proposal-controls'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');dest.mkdir(parents=True)
    (dest/'controls.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in results))
    summary={'classification':'RECORDED_MODEL_TOOL_PROPOSAL_GOVERNANCE_CONTROL_NOT_NEW_MODEL_EVALUATION',
        'actual_final_owner_scoped_trajectories_replayed':len(results),'same_tool_call_and_prestate_step_pairs':step_count,
        'same_protected_candidate_native_check_pairs':native_pairs,'new_arm_differences':0,
        'actual_final_poststate_mismatches':0,'test_fixture_only':True,'provider_calls':0,'official_scores':None}
    (dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (ROOT/'LATEST_RECORDED_PROPOSAL_CONTROLS.json').write_text(json.dumps({'directory':str(dest)},indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
