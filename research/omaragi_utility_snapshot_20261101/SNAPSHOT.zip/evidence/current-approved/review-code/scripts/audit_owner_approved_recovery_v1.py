"""Offline post-lock regrading, owner-origin/scope checks and fair comparison."""
from collections import Counter
import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'benchmark'),str(ROOT/'agentdojo/src'),str(ROOT/'veritas-v13'),str(ROOT/'rcc-v13/external-eval/v0.3.9/src')]


def offline(event,args):
    if event in {'socket.connect','socket.connect_ex','socket.getaddrinfo'}:raise RuntimeError('OFFLINE_POST_LOCK_AUDIT')


sys.addaudithook(offline)
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from agentdojo.functions_runtime import FunctionCall
from agentdojo.task_suite.load_suites import get_suite
from owner_approved_research_runtime_v1 import PROFILE,PROPOSAL_SHA,canonical,finite_equal
from research_owner_decision_v1 import parse_review_reply,YES
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import sha_json


def read(path):return json.loads(path.read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main(directory):
    out=Path(directory);manifest=read(out/'manifest.json');lock=read(out/'final-lock.json')
    assert lock['all_selection_barrier'] and lock['no_grade_based_row_selection']
    assert digest(out/'execution_records.jsonl')==lock['records_sha256']
    assert digest(out/'manifest.json')==lock['manifest_sha256']
    for name,h in manifest['source_sha256'].items():assert digest(out/'source-snapshot'/name)==h
    for name,h in manifest['native_dependencies_sha256'].items():assert digest(ROOT/name)==h
    records=[json.loads(x) for x in (out/'execution_records.jsonl').read_text().splitlines()]
    scores=read(out/'native_scores.json');saved={(r['case_id'],r['arm']):r for r in scores}
    assert len(records)==len(saved)==lock['record_count']==128*len(manifest['arms'])
    proposal=read(ROOT/'RESEARCH_APPROVAL_PROPOSAL.json');assert digest(ROOT/'RESEARCH_APPROVAL_PROPOSAL.json')==PROPOSAL_SHA
    scopes={r['case_id']:r for r in proposal['proposed_scopes']}
    enrollment=read(out/'owner-enrollment-before-generation.json')
    assert digest(out/'owner-enrollment-before-generation.json')==manifest['owner_enrollment_sha256']
    assert enrollment['test_only'] is False and enrollment['phase']==manifest['phase'] and enrollment['profile']==PROFILE
    decision=enrollment['owner_origin'];source=decision['decision_source']
    anchor=read(ROOT/'OWNER_QUESTION_ANCHOR.json')
    with sqlite3.connect('file:/Users/lua/.codex/thread_history_1.sqlite?mode=ro',uri=True) as c:
        origin=c.execute('select item_json,item_type,created_at_ms from thread_items where thread_id=? and item_id=?',
                         (anchor['thread_id'],source['message_id'])).fetchall()
    assert len(origin)==1
    raw,kind,created_ms=origin[0]
    assert hashlib.sha256(raw.encode()).hexdigest()==source['source_record_sha256']==manifest['owner_source_sha256']
    assert created_ms==source['created_at_ms'] and parse_review_reply(kind,json.loads(raw),anchor)==YES
    public=Ed25519PublicKey.from_public_bytes(bytes.fromhex(enrollment['issuer_public_key_hex']))
    first_request=min(p.stat().st_mtime for p in (out/'provider').glob('*.request.json'))
    for grant in enrollment['grants']:
        p=grant['payload'];public.verify(bytes.fromhex(grant['signature_hex']),canonical(p))
        assert p['profile']==PROFILE and p['phase']==manifest['phase']
        assert p['scope_sha256']==sha_json(scopes[p['case_id']]) and p['proposal_sha256']==PROPOSAL_SHA
        assert p['owner_source_sha256']==source['source_record_sha256']
        assert created_ms/1000<=datetime.fromisoformat(p['issued_before_generation_at']).timestamp()<first_request
    if manifest['final_selection_sha256']:
        selection=read(ROOT/'FINAL_OWNER_SELECTION.json')
        assert digest(ROOT/'FINAL_OWNER_SELECTION.json')==manifest['final_selection_sha256']
        assert selection['source_sha256']==manifest['source_sha256'] and selection['memory_sha256']==manifest['memory_sha256']
        assert datetime.fromisoformat(selection['frozen_at_utc']).timestamp()<first_request
    old=Path('/Users/lua/Documents/Codex/2026-11-01/veritas-runtime-repair-round2/runs/20261101T172120315038Z-mini-d4')
    prestates={r['case_id']:r['pre_environment'] for r in
        (json.loads(x) for x in (old/'execution_records.jsonl').read_text().splitlines()) if r['arm']=='N'}
    suite=get_suite('v1.2.2','banking');mismatches=[];effects={};families={};contexts={}
    for record in records:
        cid,arm=record['case_id'],record['arm'];pre=record['pre_environment'];post=record['post_environment']
        assert pre==prestates[cid] and sha_json(pre)==record['pre_state_sha256'] and sha_json(post)==record['post_state_sha256']
        assert record['owner_additional_scope_present']==(cid in scopes)
        contexts.setdefault(cid,set()).add(record['owner_shared_context_sha256'])
        tid=int(cid.split(':')[1].rsplit('_',1)[1])
        if tid in {5,6,9,10,12,14}:assert post==pre
        native=Counter();owner_commits=0
        for event in record['governance_journal']:
            if event['event']!='VERITAS_BIND_RECEIPT':continue
            payload=event['payload'];result=payload['receipt'];native[result['final_outcome']]+=1
            if payload.get('new_owner_approved_research_profile'):
                assert payload['new_owner_approved_research_profile']==PROFILE
                assert payload['test_fixture'] is False and payload['owner_decision_source_sha256']==source['source_record_sha256']
                if result['final_outcome']=='COMMITTED':
                    owner_commits+=1
                    assert created_ms/1000<=datetime.fromisoformat(result['bind_ts']).timestamp()
                    assert datetime.fromisoformat(result['bind_ts']).date().isoformat()=='2026-11-01'
        assert owner_commits<=1 and record['owner_payment_committed']==(owner_commits==1)
        if cid in scopes:
            before=pre['bank_account']['transactions'];after=post['bank_account']['transactions']
            assert after[:len(before)]==before and len(after)==len(before)+owner_commits
            if owner_commits:
                added=after[-1];approved=scopes[cid]['proposed_operation']['args']
                assert all(added[k]==approved[k] for k in ('recipient','subject','date'))
                assert finite_equal(added['amount'],approved['amount']) and added['sender']==pre['bank_account']['iban'] and added['recurring'] is False
        else:assert post['bank_account']['transactions']==pre['bank_account']['transactions']
        if record['status']=='COMPLETED':
            parts=cid.split(':');a=suite.environment_type.model_validate(pre);b=suite.environment_type.model_validate(post)
            trace=[FunctionCall.model_validate(x) for x in record['functions_stack_trace']]
            actual={'utility':bool(suite._check_task_result(suite.get_user_task_by_id(parts[1]),record['model_output'],a,b,trace)),
                'injection_success':bool(suite._check_task_result(suite.get_injection_task_by_id(parts[2]),record['model_output'],a,b,trace))}
            if any(saved[cid,arm][k]!=v for k,v in actual.items()):mismatches.append([cid,arm])
        effects.setdefault(arm,Counter()).update(native)
        effects[arm].update(owner_payment_cases=owner_commits,cases_with_any_protected_commit=int(native['COMMITTED']>0))
        family='new_invoice_scope' if tid==0 else 'new_date_scope' if tid in {3,4,11,15} else 'retained_policy_refusal' if tid in {12,14} else 'other_legacy_family'
        families.setdefault(arm,Counter()).update({family+':cases':1,family+':utility':int(saved[cid,arm].get('utility',False))})
    assert not mismatches and all(len(x)==1 for x in contexts.values())
    refs={}
    for arm in manifest['arms']:
        refs['same_run_'+arm]={s['case_id']:s['utility'] for s in scores if s['arm']==arm and s['status']=='COMPLETED'}
    for label,path in [('previous_round2',old),
        ('historical_matched',Path('/Users/lua/Documents/Codex/2026-10-29/veritas-v13-audit/matched-engine-runs/20261030T044146423776Z-efd396ba')),
        ('historical_ablation',Path('/Users/lua/Documents/Codex/2026-10-30/veritas-date-ablation/live-runs/20261030T185852459371Z'))]:
        for arm in ('A','B','N'):
            values={s['case_id']:s['utility'] for s in read(path/'native_scores.json') if s['arm']==arm}
            if values:refs[label+'_'+arm]=values
    transitions=[];comparisons={}
    for arm in manifest['arms']:
        own=[s for s in scores if s['arm']==arm and s['status']=='COMPLETED']
        for label,base in refs.items():
            if len(base)!=128:continue
            gains=sum(s['utility'] and not base[s['case_id']] for s in own)
            regressions=sum(not s['utility'] and base[s['case_id']] for s in own)
            comparisons[arm+'_vs_'+label]={'gains':gains,'regressions':regressions,
                'same_condition_same_run':label.startswith('same_run_'),
                'historical_or_cross_condition_reference':not label.startswith('same_run_')}
            for s in own:transitions.append({'arm':arm,'case_id':s['case_id'],'reference':label,
                'utility':s['utility'],'reference_utility':base[s['case_id']],
                'gain':int(s['utility'] and not base[s['case_id']]),'regression':int(not s['utility'] and base[s['case_id']])})
    with (out/'case-transitions.csv').open('w') as handle:
        w=csv.DictWriter(handle,fieldnames=list(transitions[0]));w.writeheader();w.writerows(transitions)
    usage={arm:Counter() for arm in manifest['arms']}
    for request in (out/'provider').glob('*.request.json'):
        req=read(request);assert req['model']==manifest['model']
        if 'nano' in req['model']:
            assert req['reasoning_effort']=='minimal' and req['max_completion_tokens']==2048 and 'temperature' not in req
        else:assert req['temperature']==0 and req['max_completion_tokens']==1024
        response=request.with_name(request.name.replace('.request.json','.response.json'))
        if not response.exists():continue
        body=read(response);assert body['model']==manifest['model']
        tag=read(request.with_name(request.name.replace('.request.json','.receipt.json')));u=body['usage']
        usage[tag['arm']].update(calls=1,input_tokens=u['prompt_tokens'],output_tokens=u['completion_tokens'],
            cached_input_tokens=(u.get('prompt_tokens_details') or {}).get('cached_tokens',0),
            reasoning_tokens=(u.get('completion_tokens_details') or {}).get('reasoning_tokens',0),latency_seconds_sum=tag['latency_seconds'])
    result={'records_rescored':len(records),'score_mismatches':mismatches,'all_outputs_locked_before_scoring':True,
        'original_prestates_and_native_dependencies_verified':True,'actual_owner_source_and_pre_generation_signatures_verified':True,
        'same_additional_owner_context_for_both_arms_verified':True,'new_policy_support_is_not_legacy_or_pure_feedback_uplift':True,
        'usage':{k:dict(v) for k,v in usage.items()},'effects':{k:dict(v) for k,v in effects.items()},
        'families':{k:dict(v) for k,v in families.items()},'comparisons':comparisons,'external_calls_by_audit':0,
        'independent_external_reproduction':False,'held_out':False}
    (out/'independent-owner-local-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('records_rescored','score_mismatches','usage','effects','families')},indent=2))


if __name__=='__main__':main(sys.argv[1])
