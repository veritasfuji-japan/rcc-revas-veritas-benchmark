"""Authority-preserving ablations. No clock or new date authority is issued.

Every protected effect uses the original RCCVeritasExecutor and Bind core.
Historical host-signed date assertions are data, never admission evidence.
"""
from __future__ import annotations

import copy
from collections import Counter
from dataclasses import dataclass
from typing import Any

from governance_feedback_v1 import with_governance_feedback
from matched_engine_adapter_v1 import frozen_engine_hint
from research_source_planner_v1 import next_source_proposal
from trusted_proposal_repair_v1 import (
    monthly_query, monthly_spending_answer, propose,
    subject_spending_answer, subject_spending_query,
)
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import (
    jsonable, make_runtime_class, sha_json,
)
from scripts.agentdojo_final_runner_integration_v0_1 import FrozenAgentDojoOpenAIPipeline


@dataclass(frozen=True)
class Mode:
    name: str
    feedback: bool = False
    source_package: bool = False
    date_requested: bool = False


MODES = {
    'B': Mode('B'),
    'F': Mode('F', feedback=True),
    'S': Mode('S', source_package=True),
    'N': Mode('N', feedback=True, source_package=True),
    'D_DENIED': Mode('D_DENIED', date_requested=True),
    'C_STRICT': Mode('C_STRICT', feedback=True, source_package=True, date_requested=True),
}
MODE_DESCRIPTIONS = {
    'B': 'Original RCC+VERITAS baseline',
    'F': 'Typed iterative refusal feedback only; original prompt, no source executor',
    'S': 'Source proposal/calculation/completion package, hint and bounded controller only',
    'N': 'Developed optimization package without any date issuance',
    'D_DENIED': 'Date-only requested but not admitted: no independent authority contract; effective B',
    'C_STRICT': 'Full C requested under original authority checks: date denied; effective N',
}


def no_date_hint() -> str:
    hint, marker, _ = frozen_engine_hint().partition(' For an immediate payment,')
    if not marker:
        raise RuntimeError('FROZEN_DATE_HINT_BOUNDARY_NOT_FOUND')
    return hint


class DateAuthorityUnavailable:
    """No approved issuer/policy evidence exists in this experiment.

    No synthetic signature, wall-clock value, benchmark gold or fixture grants
    this missing authority. This class has no accepting branch.
    """
    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    def request(self, context: str) -> None:
        self.events.append({'event': 'DATE_AUTHORITY_UNAVAILABLE', 'context': context,
                            'independent_authority_evidence_present': False,
                            'date_issued': False, 'admission_granted': False})
        return None


class AblationSession:
    def __init__(self, *, mode: Mode, case_id: str, task: Any, env: Any,
                 gate: Any, suite: Any, actor_fixture_verified: bool) -> None:
        self.mode = mode
        self.request = task.PROMPT
        self.initial = env.model_dump(mode='json')
        self.journal: list[dict[str, Any]] = []
        self.calls: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.repeats: Counter = Counter()
        self.no_progress = False
        self.date_authority = DateAuthorityUnavailable()
        base = make_runtime_class(
            arm='B', rcc_gate=gate, user_task_id=int(task.ID.rsplit('_', 1)[1]),
            case_id=case_id, prompt=self.request, journal_rows=self.journal,
            authority_admitted=actor_fixture_verified,
        )
        if mode.feedback:
            base = with_governance_feedback(base, self.journal)
        owner = self

        class RecordedRuntime(base):
            def run_function(runtime, state, function, kwargs, raise_on_error=False):
                before = state.model_dump(mode='json')
                revised, evidence = (propose(owner.request, function, kwargs, before)
                                     if mode.source_package else (copy.deepcopy(kwargs), []))
                start = len(owner.journal)
                value, error = super().run_function(
                    state, function, revised, raise_on_error=raise_on_error)
                after = state.model_dump(mode='json')
                owner.calls.append({
                    'function': function, 'args': copy.deepcopy(revised),
                    'id': None, 'placeholder_args': None,
                    'raw_args': copy.deepcopy(kwargs), 'source_evidence': evidence,
                    'pre_state_sha256': sha_json(before),
                    'post_state_sha256': sha_json(after), 'error': error,
                    'journal_range': [start, len(owner.journal)],
                })
                if mode.source_package:
                    key = sha_json({'proposal': {'function': function, 'args': revised},
                                    'state': after, 'error': error})
                    owner.repeats[key] += 1
                    if owner.repeats[key] >= 3:
                        owner.no_progress = True
                return value, error

        self.runtime = RecordedRuntime(suite.tools)

    def final_trace(self) -> list[dict[str, Any]]:
        fields = ('function', 'args', 'id', 'placeholder_args')
        return [{key: row[key] for key in fields} for row in self.calls]

    def complete_from_source(self, env: Any, output: Any) -> Any:
        if not self.mode.source_package:
            return output
        if monthly_query(self.request) or subject_spending_query(self.request):
            value, error = self.runtime.run_function(
                env, 'get_most_recent_transactions', {'n': max(1, len(env.bank_account.transactions))})
            value = jsonable(value)
            answer = (monthly_spending_answer(self.request, value, env.bank_account.iban)
                      or subject_spending_answer(self.request, value, env.bank_account.iban)) if error is None else None
            if answer is not None:
                output = [{'type': 'text', 'content': answer}]
        for _ in range(8):
            # No date is synthesized. The original gate remains authoritative.
            proposal = next_source_proposal(
                self.request, self.initial, env.model_dump(mode='json'), None,
                payment_committed=False)
            if proposal is None:
                break
            if proposal['function'] == 'send_money':
                self.events.append({'event': 'MISSING_INDEPENDENT_DATE_NO_PROPOSAL_DISPATCH',
                                    'source': proposal['source']})
                break
            _, error = self.runtime.run_function(env, proposal['function'], proposal['args'])
            if error:
                break
            output = [{'type': 'text', 'content': 'The source-bound requested operation was completed through the native execution path. Unrelated operations were not authorized.'}]
        return output


class AblationLLM:
    def __init__(self, client: Any, session: AblationSession) -> None:
        self.base = FrozenAgentDojoOpenAIPipeline(client)
        self.session = session

    def query(self, query, runtime, env, messages=(), extra_args=None):
        if self.session.mode.date_requested:
            self.session.date_authority.request('BEFORE_MODEL_GENERATION')
        if self.session.mode.source_package and self.session.no_progress:
            stop = {'role': 'assistant', 'content': [{'type': 'text', 'content':
                    'Stopped after repeated identical tool calls without progress.'}], 'tool_calls': None}
            return query, runtime, env, [*messages, stop], dict(extra_args or {})
        prepared = copy.deepcopy(messages)
        if self.session.mode.source_package:
            prepared[0]['content'][0]['content'] += '\n' + no_date_hint()
        result = self.base.query(query, runtime, env, prepared, extra_args or {})
        history = list(result[3])
        history[0] = messages[0]
        return result[0], result[1], result[2], history, result[4]
