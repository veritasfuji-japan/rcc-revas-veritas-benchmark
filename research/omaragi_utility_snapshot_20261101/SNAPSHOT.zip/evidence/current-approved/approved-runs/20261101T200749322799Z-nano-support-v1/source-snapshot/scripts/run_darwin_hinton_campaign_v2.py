"""Bounded Nano development, then locked Mini comparison; original Native gate."""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import threading
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
PRIOR = Path('/Users/lua/Documents/Codex/2026-10-30/veritas-date-ablation')
OLD = PRIOR / 'live-runs/20261030T185852459371Z'
sys.path[:0] = [str(ROOT/'benchmark'), str(ROOT/'agentdojo/src'),
               str(ROOT/'veritas-v13'), str(ROOT/'rcc-v13/external-eval/v0.3.9/src')]
from agentdojo.agent_pipeline.agent_pipeline import AgentPipeline, load_system_message
from agentdojo.agent_pipeline.basic_elements import InitQuery, SystemMessage
from agentdojo.agent_pipeline.tool_execution import ToolsExecutionLoop, ToolsExecutor
from agentdojo.functions_runtime import FunctionCall
from agentdojo.task_suite.load_suites import get_suite
from agentdojo.task_suite.task_suite import model_output_from_messages
from darwin_hinton_feedback_v2 import RouteMemory, with_feedback, memory_from_records
from date_ablation_native_v1 import AblationSession, AblationLLM, Mode, MODES
from immutable_effect_anchor_v3 import with_effect_anchor
from research_provider_v1 import CumulativeBudget, authorized_key
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import (
    load_rcc_gate, sha_json, verify_authority_fixture, jsonable,
)

NANO = 'gpt-5-nano-2025-08-07'
MINI = 'gpt-4.1-mini-2025-04-14'


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Budget(CumulativeBudget):
    def __init__(self):
        self.path = ROOT/'repair-api-budget.sqlite'
        assert self.path.exists()
        with sqlite3.connect(self.path) as c:
            assert c.execute('select limit_micro from settings where id=1').fetchone()[0] == 5000000

    def summary(self):
        with sqlite3.connect(self.path) as c:
            spent, held, calls = c.execute('select sum(charged),sum(reserved),count(*) from calls').fetchone()
        return {'cumulative_estimate_usd': spent/1e6, 'new_round_usd': (spent-2697274)/1e6,
                'uncertain_or_reserved_usd': held/1e6, 'new_provider_calls': calls-8900,
                'cumulative_hard_cap_usd': 5.0,'remaining_budget_including_reservations_usd':(5000000-spent-held)/1e6}


class Wire:
    def __init__(self, model, budget, directory, cache=None):
        from openai import OpenAI
        self.base = OpenAI(api_key=authorized_key(), base_url='https://api.openai.com/v1',
                           max_retries=0, timeout=180)
        self.model, self.budget, self.directory = model, budget, directory
        self.context = threading.local()
        self.chat = SimpleNamespace(completions=self)
        self.failed = threading.Event()
        self.cache=cache or {};self.cache_lock=threading.Lock();self.cache_used=0

    def create(self, **kwargs):
        if self.failed.is_set():
            raise RuntimeError('PROVIDER_CIRCUIT_HALTED')
        assert kwargs.pop('model') == MINI and kwargs.pop('temperature') == 0
        kwargs['model'] = self.model
        limit = 2048 if self.model == NANO else 1024
        kwargs['max_completion_tokens'] = limit
        if self.model == NANO:
            kwargs['reasoning_effort'] = 'minimal'
        else:
            kwargs['temperature'] = 0
        key=(self.context.case_id,self.context.arm,sha_json(kwargs))
        with self.cache_lock:
            cached=self.cache.get(key,[])
            if cached:
                entry=cached.pop(0);self.cache_used+=1
                with (self.directory.parent/'provider-cache-replay.jsonl').open('a') as handle:
                    handle.write(json.dumps({'case_id':key[0],'arm':key[1],
                        'request_sha256':key[2],'source_response':str(entry['path']),
                        'source_response_sha256':digest(entry['path'])})+'\n')
                from openai.types.chat import ChatCompletion
                return ChatCompletion.model_validate(entry['data'])
        identity = self.budget.reserve(self.model, kwargs, limit)
        prefix = self.directory/identity
        dump(prefix.with_suffix('.request.json'), kwargs)
        started = time.monotonic()
        tag = {'case_id': self.context.case_id, 'arm': self.context.arm}
        try:
            response = self.base.chat.completions.create(**kwargs)
        except Exception as exc:
            self.failed.set()
            self.budget.uncertain(identity)
            code=getattr(exc,'code',None)
            if not isinstance(code,str) or not code.replace('_','').isalnum():code=None
            dump(prefix.with_suffix('.error.json'), {**tag,'exception_type':type(exc).__name__,
                 'http_status':getattr(exc,'status_code',None),'error_code':code,
                 'cause_type':type(exc.__cause__).__name__ if exc.__cause__ else None,
                 'automatic_retry':False})
            raise RuntimeError('PROVIDER_FAILED_NO_RETRY') from None
        dump(prefix.with_suffix('.response.json'), response.model_dump(mode='json'))
        dump(prefix.with_suffix('.receipt.json'), {**tag,'latency_seconds':time.monotonic()-started})
        if response.usage is None:
            self.failed.set(); self.budget.uncertain(identity)
            raise RuntimeError('PROVIDER_USAGE_MISSING')
        self.budget.settle(identity,self.model,response.usage.model_dump(mode='json'))
        return response


class LearnedLLM:
    def __init__(self, wire, session, memory, use_hint):
        self.base = AblationLLM(wire,session)
        self.memory, self.use_hint = memory, use_hint

    def query(self, query, runtime, env, messages=(), extra_args=None):
        prepared = copy.deepcopy(messages)
        if self.use_hint:
            prepared[0]['content'][0]['content'] += '\n'+self.memory.learned_hint()
        result = self.base.query(query,runtime,env,prepared,extra_args)
        history = list(result[3]); history[0] = messages[0]
        return result[0],result[1],result[2],history,result[4]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase',choices=['nano-d4','mini-d4'],required=True)
    parser.add_argument('--previous',type=Path)
    parser.add_argument('--resume',type=Path)
    parser.add_argument('--selected',choices=['D4'],default='D4')
    parser.add_argument('--workers',type=int,default=6)
    args = parser.parse_args()
    auth = json.loads((ROOT/'API_AUTHORIZATION.json').read_text())
    assert auth['development_model'] == NANO and auth['final_model'] == MINI
    assert auth['maximum_new_cost_including_new_reservations_usd']==2.273205
    assert not auth['date_or_action_authority_granted']
    source = [json.loads(x) for x in (OLD/'execution_records.jsonl').read_text().splitlines()]
    cases = [r for r in source if r['arm']=='B']
    assert len(cases)==128
    memory = memory_from_records([r for r in source if r['arm']=='F'])
    if args.previous:
        memory = RouteMemory.from_dict(json.loads((args.previous/'route-memory-before.json').read_text()))
        previous = [json.loads(x) for x in (args.previous/'execution_records.jsonl').read_text().splitlines()]
        previous = [r for r in previous if r['arm'] in {'D1','D2','D3'}]
        if args.phase not in ('mini-d4','nano-d4'):
            memory = memory_from_records(previous, memory)
    model = MINI if args.phase=='mini-d4' else NANO
    arms = ['B','N','D4'] if args.phase=='mini-d4' else ['N','D4']
    out = ROOT/'runs'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+args.phase)
    out.mkdir(parents=True); (out/'provider').mkdir();(out/'cases').mkdir()
    files = ['darwin_hinton_feedback_v2.py','scripts/run_darwin_hinton_campaign_v2.py',
             'date_ablation_native_v1.py','governance_feedback_v1.py','research_provider_v1.py',
             'trusted_proposal_repair_v1.py','research_source_planner_v1.py',
             'agentdojo_constraint_resolver_v0_1.py','original_request_authority_lineage_v1.py',
             'scripts/agentdojo_clean_ab_canonical_final_runner_v2_8.py',
             'scripts/agentdojo_final_runner_integration_v0_1.py',
             'scripts/agentdojo_openai_frozen_adapter_v0_1.py',
             'matched_engine_adapter_v1.py','research_payment_date_v1.py',
             'scripts/run_research_models_v1.py','immutable_effect_anchor_v3.py']
    selection=None
    if args.phase=='mini-d4':
        selection=json.loads((ROOT/'FINAL_SELECTION.json').read_text())
        assert selection['candidate']=='D4' and selection['frozen_before_final_generation']
        assert selection['final_model']==model and selection['arms']==arms
        assert selection['memory_sha256']==sha_json(memory.to_dict())
        assert selection['source_sha256']=={f:digest(ROOT/'benchmark'/f) for f in files}
        assert selection['original_cases_sha256']==sha_json(cases)
        for name,expected in selection['native_dependencies_sha256'].items():
            assert digest(ROOT/name)==expected,'FROZEN_NATIVE_DEPENDENCY_CHANGED'
    recovered=[];cache={}
    if args.resume:
        previous_manifest=json.loads((args.resume/'manifest.json').read_text())
        assert previous_manifest['phase']==args.phase and previous_manifest['model']==model
        assert previous_manifest['arms']==arms
        assert previous_manifest['memory_sha256']==sha_json(memory.to_dict())
        for name in files:
            if name!='scripts/run_darwin_hinton_campaign_v2.py':
                assert digest(ROOT/'benchmark'/name)==previous_manifest['source_sha256'][name]
        previous_records=[json.loads(x) for x in (args.resume/'execution_records.jsonl').read_text().splitlines()]
        recovered=[r for r in previous_records if r['status']=='COMPLETED']
        chain=[];current=args.resume
        while current:
            assert current not in chain,'RECOVERY_CYCLE'
            chain.append(current)
            prior_manifest=json.loads((current/'manifest.json').read_text())
            parent=prior_manifest.get('recovery_from')
            current=Path(parent) if parent else None
        for prior_run in reversed(chain):
            for request in sorted((prior_run/'provider').glob('*.request.json'),key=lambda p:p.stat().st_mtime_ns):
                response=request.with_name(request.name.replace('.request.json','.response.json'))
                receipt=request.with_name(request.name.replace('.request.json','.receipt.json'))
                if not response.exists() or not receipt.exists():continue
                params=json.loads(request.read_text());tag=json.loads(receipt.read_text())
                key=(tag['case_id'],tag['arm'],sha_json(params))
                cache.setdefault(key,[]).append({'path':response,'data':json.loads(response.read_text())})
    manifest = {'scope':'LIVE_DARWIN_HINTON_DEVELOPMENT_OR_LOCKED_MODEL_TRANSFER',
                'phase':args.phase,'model':model,'arms':arms,'cases_per_arm':128,
                'held_out':False,'weights_updated':False,'date_authority_issued':False,
                'source_sha256':{f:digest(ROOT/'benchmark'/f) for f in files},
                'memory_sha256':sha_json(memory.to_dict()),'authorization_sha256':digest(ROOT/'API_AUTHORIZATION.json'),
                'original_native_gate_preserved':True,'candidate_selection_before_scoring':True,
                'authority_support_or_scorer_changed':False,'max_tool_iters':15,'outer_attempts':3,
                'automatic_retries':False,'fallback_models':False}
    if selection is not None:
        manifest['selection_lock_sha256']=digest(ROOT/'FINAL_SELECTION.json')
    manifest.update(workers=args.workers,recovery_from=str(args.resume) if args.resume else None,
                    retained_completed_cases=len(recovered),
                    retained_output_hashes={r['case_id']+':'+r['arm']:sha_json(r) for r in recovered},
                    cached_provider_responses=sum(len(v) for v in cache.values()),
                    operational_http_timeout_seconds=180)
    dump(out/'manifest.json',manifest);dump(out/'route-memory-before.json',memory.to_dict())
    for file in files:
        target=out/'source-snapshot'/file;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((ROOT/'benchmark'/file).read_bytes())
    budget=Budget();wire=Wire(model,budget,out/'provider',cache=cache)
    suite=get_suite('v1.2.2','banking');actor=verify_authority_fixture()

    def execute(row,arm):
        cid=row['case_id'];wire.context.case_id=cid;wire.context.arm=arm
        task=suite.get_user_task_by_id(cid.split(':')[1])
        env=suite.environment_type.model_validate(row['pre_environment'])
        mode=MODES[arm] if arm in ('B','N') else Mode(arm,source_package=True)
        session=AblationSession(mode=mode,case_id=cid,task=task,env=env,
                                gate=load_rcc_gate(ROOT/'rcc-v13'),suite=suite,
                                actor_fixture_verified=actor)
        if arm.startswith('D'):
            session.runtime=with_feedback(type(session.runtime),session.journal,memory)(suite.tools)
        if arm=='D4':
            def stop():session.no_progress=True
            session.runtime=with_effect_anchor(type(session.runtime),session.journal,
                task.PROMPT,session.initial,int(task.ID.rsplit('_',1)[1]),stop)(suite.tools)
        llm=LearnedLLM(wire,session,memory,arm=='D4')
        pipeline=AgentPipeline([SystemMessage(load_system_message(None)),InitQuery(),llm,
                               ToolsExecutionLoop([ToolsExecutor(),llm])])
        messages=[];output=None;status='COMPLETED';failure=None
        try:
            for _ in range(3):
                _,_,env,messages,_=pipeline.query(task.PROMPT,session.runtime,env)
                output=model_output_from_messages(messages)
                if output is not None:break
            output=session.complete_from_source(env,output or [])
            if arm=='D4' and any(e['event']=='MISSING_INDEPENDENT_DATE_NO_PROPOSAL_DISPATCH' for e in session.events):
                output=[{'type':'text','content':'Independently authorized parts may have completed. A required payment was not executed because independent date authority was unavailable.'}]
        except Exception as exc:
            status='ERROR';failure=type(exc).__name__
        record={'case_id':cid,'arm':arm,'status':status,'failure':failure,
                'pre_environment':session.initial,'post_environment':env.model_dump(mode='json'),
                'pre_state_sha256':sha_json(session.initial),'post_state_sha256':sha_json(env.model_dump(mode='json')),
                'model_output':jsonable(output or []),'model_history':jsonable(messages),
                'functions_stack_trace':session.final_trace(),'governance_journal':session.journal,
                'source_events':session.events,'date_issued':False}
        dump(out/'cases'/(cid.replace(':','_')+'_'+arm+'.json'),record)
        return record

    print(json.dumps({'run_directory':str(out),'phase':args.phase,'model':model,'arms':arms,'budget':budget.summary()}),flush=True)
    # First real case doubles as model/account compatibility verification.
    records=list(recovered)
    for record in recovered:
        dump(out/'cases'/(record['case_id'].replace(':','_')+'_'+record['arm']+'.json'),record)
    existing={(r['case_id'],r['arm']) for r in records}
    pending=[(row,arm) for row in cases for arm in arms if (row['case_id'],arm) not in existing]
    assert pending, 'NO_MISSING_CASES_TO_RESUME'
    first=pending.pop(0)
    records.append(execute(*first))
    if wire.failed.is_set():
        dump(out/'early-provider-failure.json',{'budget':budget.summary(),'record':records[0]})
        raise RuntimeError('FIRST_CASE_FAILED_NO_RETRY_OR_FALLBACK')
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(execute,row,arm) for row,arm in pending]
        for future in as_completed(futures):
            records.append(future.result())
            if len(records)%16==0 or len(records)==128*len(arms):
                print(json.dumps({'finished':len(records),'total':128*len(arms),
                                 'errors':sum(r['status']=='ERROR' for r in records),'budget':budget.summary()}),flush=True)
    records.sort(key=lambda r:(r['case_id'],r['arm']))
    path=out/'execution_records.jsonl'
    path.write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in records))
    dump(out/'final-lock.json',{'records_sha256':digest(path),'manifest_sha256':digest(out/'manifest.json'),
         'record_count':len(records),'all_selection_barrier':True,'no_grade_based_row_selection':True})
    scores=[]
    for r in records:
        s={'case_id':r['case_id'],'arm':r['arm'],'status':r['status']}
        if r['status']=='COMPLETED':
            parts=r['case_id'].split(':');pre=suite.environment_type.model_validate(r['pre_environment'])
            post=suite.environment_type.model_validate(r['post_environment'])
            trace=[FunctionCall.model_validate(c) for c in r['functions_stack_trace']]
            s.update(utility=bool(suite._check_task_result(suite.get_user_task_by_id(parts[1]),r['model_output'],pre,post,trace)),
                     injection_success=bool(suite._check_task_result(suite.get_injection_task_by_id(parts[2]),r['model_output'],pre,post,trace)))
        scores.append(s)
    totals={a:{'enrolled':128,'scored':sum(s['status']=='COMPLETED' for s in scores if s['arm']==a),
               'utility':sum(s.get('utility',False) for s in scores if s['arm']==a),
               'injection_success':sum(s.get('injection_success',False) for s in scores if s['arm']==a)} for a in arms}
    summary={'phase':args.phase,'model':model,'arms':totals,'budget':budget.summary(),
             'execution_errors':sum(r['status']=='ERROR' for r in records),'held_out':False,
             'native_refusals_by_flag':memory_from_records(records).to_dict(),
             'retained_completed_cases':len(recovered),'provider_cached_prefix_calls':wire.cache_used}
    dump(out/'native_scores.json',scores);dump(out/'summary.json',summary)
    dump(ROOT/('LATEST_'+args.phase.upper().replace('-','_')+'.json'),{'directory':str(out)})
    print(json.dumps({'run_directory':str(out),**summary}),flush=True)


if __name__=='__main__':main()
