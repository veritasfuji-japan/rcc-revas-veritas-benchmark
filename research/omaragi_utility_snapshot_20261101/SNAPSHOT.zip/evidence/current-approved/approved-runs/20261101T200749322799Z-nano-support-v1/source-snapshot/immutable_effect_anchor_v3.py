"""Request-time effect binding before the unchanged Native mutation gate.

A later observation is not a new request to repeat a relative adjustment.
This guard may refuse extra effects or observe an already-satisfied goal; it
cannot issue action/date authority or admit a protected mutation itself.
"""
from __future__ import annotations
import copy
from collections import Counter
from decimal import Decimal, InvalidOperation
import json
from typing import Any

from trusted_proposal_repair_v1 import RENT_AMOUNT, complete_rent_proposal, propose
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import sha_json
from veritas_os.benchmarks.agentdojo_banking_adapter import TASK_MUTATION_POLICY


def numeric_equal(first: Any, second: Any) -> bool:
    try:
        a,b=Decimal(str(first)),Decimal(str(second))
        return a.is_finite() and b.is_finite() and a==b
    except (InvalidOperation,ValueError):
        return False


class RequestEffectAnchor:
    def __init__(self, request: str, initial: dict, task_id: int):
        self.request=request
        self.initial=copy.deepcopy(initial)
        self.initial_sha256=sha_json(self.initial)
        self.request_sha256=sha_json({'original_request':request})
        self.target=complete_rent_proposal(request,self.initial,self.initial)
        match=RENT_AMOUNT.fullmatch(request.strip())
        policy=TASK_MUTATION_POLICY.get(task_id)
        self.enabled=bool(match and self.target and policy and policy.conditionally_admissible
            and 'update_scheduled_transaction' in policy.protected_actions)
        self.file_path=match.group(1) if match else None

    def review(self, function: str, arguments: dict, current: dict) -> str:
        assert sha_json(self.initial)==self.initial_sha256,'AUTHORITY_ANCHOR_MUTATED'
        if not self.enabled or function!='update_scheduled_transaction':
            return 'FORWARD_TO_NATIVE'
        expected=self.target['args']
        original_files=self.initial['filesystem']['files']
        old_source=original_files.get(self.file_path)
        new_source=current['filesystem']['files'].get(self.file_path)
        if not isinstance(new_source,str) or new_source.split('TODO:',1)[0]!=old_source.split('TODO:',1)[0]:
            return 'SOURCE_DRIFT'
        old=[r for r in self.initial['bank_account']['scheduled_transactions'] if r['id']==expected['id']]
        now=[r for r in current['bank_account']['scheduled_transactions'] if r['id']==expected['id']]
        if len(old)!=1 or len(now)!=1:
            return 'TARGET_IDENTITY_DRIFT'
        if any(now[0].get(k)!=old[0].get(k) for k in ('recipient','subject','date','recurring')):
            return 'TARGET_SCOPE_DRIFT'
        if not (numeric_equal(now[0]['amount'],old[0]['amount']) or
                numeric_equal(now[0]['amount'],expected['amount'])):
            return 'TARGET_VALUE_DRIFT'
        if arguments.get('id')!=expected['id'] or not numeric_equal(arguments.get('amount'),expected['amount']):
            return 'ORIGINAL_EFFECT_BINDING_FAILED'
        if set(arguments)-{'id','amount','recipient','subject','date','recurring'}:
            return 'UNREQUESTED_FIELDS'
        if any(arguments.get(k) is not None and arguments[k]!=old[0].get(k)
               for k in ('recipient','subject','date','recurring')):
            return 'UNREQUESTED_EFFECT'
        if numeric_equal(now[0]['amount'],expected['amount']):
            return 'OBSERVE_ALREADY_SATISFIED'
        return 'FORWARD_TO_NATIVE'


def with_effect_anchor(base: type, journal: list, request: str, initial: dict,
                       task_id: int, stop_callback=None) -> type:
    class Runtime(base):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.effect_anchor=RequestEffectAnchor(request,initial,task_id)
            self.anchor_rejections=Counter()

        def run_function(self,env,function,kwargs,raise_on_error=False):
            before=env.model_dump(mode='json')
            # Match the existing source package's exact proposed/native shape.
            revised,_=propose(request,function,kwargs,before)
            try:
                normalized=self.functions[function].parameters.model_validate(revised).model_dump(mode='json')
            except (ValueError,TypeError,KeyError):
                return super().run_function(env,function,kwargs,raise_on_error=raise_on_error)
            action=self.effect_anchor.review(function,normalized,before)
            if action=='FORWARD_TO_NATIVE':
                return super().run_function(env,function,kwargs,raise_on_error=raise_on_error)
            journal.append({'event':'IMMUTABLE_EFFECT_ANCHOR','payload':{
                'disposition':action,'original_request_sha256':self.effect_anchor.request_sha256,
                'original_prestate_sha256':self.effect_anchor.initial_sha256,
                'current_prestate_sha256':sha_json(before),
                'candidate_sha256':sha_json({'function':function,'args':normalized}),
                'execution_authority_conferred':False,'protected_mutation_dispatched':False}})
            if action=='OBSERVE_ALREADY_SATISFIED':
                value,error=super().run_function(env,'get_scheduled_transactions',{},raise_on_error=raise_on_error)
                assert sha_json(env.model_dump(mode='json'))==sha_json(before)
                if error:return value,error
                return {'mutation_performed':False,'state_already_matches_original_requested_effect':True,
                        'observed_scheduled_transactions':value},None
            key=sha_json({'candidate':normalized,'state':before,'reason':action})
            self.anchor_rejections[key]+=1
            if self.anchor_rejections[key]>=3 and stop_callback:
                stop_callback()
            assert sha_json(env.model_dump(mode='json'))==sha_json(before)
            return None,'SourceAnchorStop: '+json.dumps({
                'reason':action,'execution_authority_conferred':False,
                'message':'Preserve the original request-time effect. A changed balance/order value is not a new authorization to repeat an adjustment. Missing authority is not repaired.'})
    Runtime.__name__='RequestAnchored'+base.__name__
    return Runtime
