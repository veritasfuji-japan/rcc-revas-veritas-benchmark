"""Nano development then locked Mini B/E under the SAME new owner support."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'benchmark'),str(ROOT/'agentdojo/src'),str(ROOT/'veritas-v13'),str(ROOT/'rcc-v13/external-eval/v0.3.9/src')]
from agentdojo.agent_pipeline.agent_pipeline import AgentPipeline,load_system_message
from agentdojo.agent_pipeline.basic_elements import InitQuery,SystemMessage
from agentdojo.agent_pipeline.tool_execution import ToolsExecutionLoop,ToolsExecutor
from agentdojo.functions_runtime import FunctionCall
from agentdojo.task_suite.load_suites import get_suite
from agentdojo.task_suite.task_suite import model_output_from_messages
from darwin_hinton_feedback_v2 import RouteMemory,memory_from_records
from owner_approved_research_runtime_v1 import OwnerEnrollment,PROFILE,PROPOSAL_SHA,PHASES
from owner_approved_engine_v1 import OwnerResearchSession,OwnerResearchLLM
from research_provider_v1 import CumulativeBudget
from scripts.run_darwin_hinton_campaign_v2 import Wire as OriginalWire,NANO,MINI
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import load_rcc_gate,verify_authority_fixture,sha_json,jsonable


def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


class Budget(CumulativeBudget):
    def __init__(self):
        self.path=ROOT/'authority-recovery-api-budget.sqlite'
        with sqlite3.connect(self.path) as c:
            assert c.execute('select limit_micro from settings where id=1').fetchone()[0]==5000000
            c.execute("create trigger if not exists owner_provider_cap before insert on calls "
                "when (select count(*) from calls)>=13065 begin select raise(abort,'OWNER_PROVIDER_CAP_2048'); end")
    def summary(self):
        with sqlite3.connect(self.path) as c:
            charged,held,n=c.execute('select sum(charged),sum(reserved),count(*) from calls').fetchone()
        return {'cumulative_estimated_usd':charged/1e6,'new_approved_condition_usd':(charged-3264943)/1e6,
            'uncertain_or_reserved_usd':held/1e6,'new_provider_attempts':n-11017,
            'remaining_including_reservations_usd':(5000000-charged-held)/1e6,'cumulative_cap_usd':5}


class Wire(OriginalWire):
    def __init__(self,*args,enrollment,**kwargs):
        if enrollment.test_only or not enrollment.current():raise ValueError('LIVE_OWNER_DECISION_REQUIRED_FOR_PROVIDER')
        super().__init__(*args,**kwargs);self.enrollment=enrollment
    def create(self,**kwargs):
        if self.enrollment.test_only or not self.enrollment.current():
            self.failed.set();raise RuntimeError('OWNER_APPROVAL_NOT_CURRENT')
        return super().create(**kwargs)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=PHASES,required=True)
    parser.add_argument('--previous',type=Path);parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args()
    final=args.phase=='mini-support-v1';model=MINI if final else NANO
    arms=['B_SUPPORT','E_SUPPORT'] if final else ['E_SUPPORT']
    old=Path('/Users/lua/Documents/Codex/2026-11-01/veritas-runtime-repair-round2/runs/20261101T172120315038Z-mini-d4')
    cases=[r for r in (json.loads(x) for x in (old/'execution_records.jsonl').read_text().splitlines()) if r['arm']=='N']
    assert len(cases)==128
    memory_path=Path('/Users/lua/Documents/Codex/2026-11-01/veritas-runtime-repair-round2/runs/20261101T170156512351Z-nano-d4/route-memory-before.json')
    memory=RouteMemory.from_dict(json.loads(memory_path.read_text()))
    if args.previous:
        previous=[json.loads(x) for x in (args.previous/'execution_records.jsonl').read_text().splitlines()]
        assert len(previous)==128 and all(r['status']=='COMPLETED' for r in previous)
        memory=memory_from_records(previous,memory)
    files=['owner_approved_research_runtime_v1.py','owner_approved_engine_v1.py','research_owner_decision_v1.py',
        'scripts/run_owner_approved_recovery_v1.py','scripts/run_darwin_hinton_campaign_v2.py',
        'darwin_hinton_feedback_v2.py','date_ablation_native_v1.py','immutable_effect_anchor_v3.py',
        'governance_feedback_v1.py','research_provider_v1.py','trusted_proposal_repair_v1.py','research_source_planner_v1.py',
        'agentdojo_constraint_resolver_v0_1.py','original_request_authority_lineage_v1.py',
        'scripts/agentdojo_clean_ab_canonical_final_runner_v2_8.py','scripts/agentdojo_final_runner_integration_v0_1.py',
        'scripts/agentdojo_openai_frozen_adapter_v0_1.py','matched_engine_adapter_v1.py','research_payment_date_v1.py','scripts/run_research_models_v1.py']
    source_hash={name:digest(ROOT/'benchmark'/name) for name in files}
    old_selection=json.loads(Path('/Users/lua/Documents/Codex/2026-11-01/veritas-runtime-repair-round2/FINAL_SELECTION.json').read_text())
    for name,expected in old_selection['native_dependencies_sha256'].items():assert digest(ROOT/name)==expected
    enrollment=OwnerEnrollment.live(args.phase,ROOT/'owner-effect-consumption.sqlite')
    out=ROOT/'approved-runs'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+args.phase)
    out.mkdir(parents=True);(out/'provider').mkdir();(out/'cases').mkdir()
    record=enrollment.public_record();write(out/'owner-enrollment-before-generation.json',record)
    selection=None
    if final:
        assert args.previous and json.loads((args.previous/'summary.json').read_text())['execution_errors']==0
        selection={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'selected_whole_engine_version':'OWNER_RECOVERY_V1',
            'source_sha256':source_hash,'memory_sha256':sha_json(memory.to_dict()),'proposal_sha256':PROPOSAL_SHA,
            'owner_source_sha256':enrollment.decision['decision_source']['source_record_sha256'],
            'new_policy_profile':PROFILE,'new_input_condition_shared_by_arms':True,'final_model':model,'arms':arms,
            'original_case_identities_sha256':sha_json([r['case_id'] for r in cases]),
            'Nano_development_summary':json.loads((args.previous/'summary.json').read_text()),
            'native_dependencies_sha256':old_selection['native_dependencies_sha256'],
            'final_answers_not_generated_yet':True,'held_out':False,'no_rowwise_selection':True}
        selection_path=ROOT/'FINAL_OWNER_SELECTION.json'
        with selection_path.open('x') as handle:handle.write(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
    manifest={'phase':args.phase,'model':model,'arms':arms,'cases_per_arm':128,
        'classification':'NEW_EXPLICIT_OWNER_APPROVED_SYNTHETIC_RESEARCH_SUPPORT_CONDITION_NOT_LEGACY_UPLIFT',
        'source_sha256':source_hash,'memory_sha256':sha_json(memory.to_dict()),'proposal_sha256':PROPOSAL_SHA,
        'owner_enrollment_sha256':digest(out/'owner-enrollment-before-generation.json'),
        'owner_source_sha256':enrollment.decision['decision_source']['source_record_sha256'],
        'new_policy_profile':PROFILE,'all_original_prestates_preserved':True,'max_tool_iters':15,'outer_attempts':3,
        'held_out':False,'global_weights_changed':False,'same_owner_context_given_to_both_arms':True,
        'provider_max_retries':0,'http_timeout_seconds':180,'workers':args.workers,
        'final_selection_sha256':digest(ROOT/'FINAL_OWNER_SELECTION.json') if final else None,
        'native_dependencies_sha256':old_selection['native_dependencies_sha256']}
    write(out/'manifest.json',manifest);write(out/'route-memory-before.json',memory.to_dict())
    for name in files:
        p=out/'source-snapshot'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/'benchmark'/name).read_bytes())
    budget=Budget();wire=Wire(model,budget,out/'provider',enrollment=enrollment)
    suite=get_suite('v1.2.2','banking');gate=load_rcc_gate(ROOT/'rcc-v13');actor=verify_authority_fixture()

    def execute(row,arm):
        cid=row['case_id'];wire.context.case_id=cid;wire.context.arm=arm
        task=suite.get_user_task_by_id(cid.split(':')[1]);env=suite.environment_type.model_validate(row['pre_environment'])
        session=OwnerResearchSession(arm=arm,row=row,task=task,suite=suite,gate=gate,actor=actor,enrollment=enrollment,memory=memory)
        llm=OwnerResearchLLM(wire,session,memory)
        pipeline=AgentPipeline([SystemMessage(load_system_message(None)),InitQuery(),llm,ToolsExecutionLoop([ToolsExecutor(),llm])])
        status='COMPLETED';failure=None;messages=[];output=[]
        try:
            enrollment.claim_case(cid,arm)
            for _ in range(3):
                _,_,env,messages,_=pipeline.query(task.PROMPT,session.runtime,env)
                output=model_output_from_messages(messages)
                if output is not None:break
            output=session.complete(env,output or [])
        except Exception as exc:status='ERROR';failure=type(exc).__name__
        result={'case_id':cid,'arm':arm,'status':status,'failure':failure,'original_request':task.PROMPT,
            'pre_environment':session.initial,'post_environment':env.model_dump(mode='json'),
            'pre_state_sha256':sha_json(session.initial),'post_state_sha256':sha_json(env.model_dump(mode='json')),
            'model_output':jsonable(output or []),'model_history':jsonable(messages),
            'functions_stack_trace':session.trace(),'governance_journal':session.journal,'source_events':session.events,
            'owner_additional_scope_present':session.scope.scope is not None,'owner_payment_committed':session.scope.payment_committed,
            'owner_shared_context_sha256':sha_json(session.scope.shared_model_context()),'new_policy_profile':PROFILE}
        write(out/'cases'/(cid.replace(':','_')+'_'+arm+'.json'),result);return result

    print(json.dumps({'run_directory':str(out),'phase':args.phase,'model':model,'arms':arms,'budget':budget.summary()}),flush=True)
    pending=[(r,a) for r in cases for a in arms];first=pending.pop(0);records=[execute(*first)]
    if wire.failed.is_set():
        write(out/'first-provider-failure.json',{'record':records[0],'budget':budget.summary()})
        raise RuntimeError('FIRST_PROVIDER_FAILURE_NO_RETRY')
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(execute,r,a) for r,a in pending]
        for future in as_completed(futures):
            records.append(future.result())
            if len(records)%16==0 or len(records)==128*len(arms):
                print(json.dumps({'finished':len(records),'total':128*len(arms),
                    'errors':sum(r['status']=='ERROR' for r in records),'budget':budget.summary()}),flush=True)
    records.sort(key=lambda r:(r['case_id'],r['arm']))
    path=out/'execution_records.jsonl';path.write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in records))
    write(out/'final-lock.json',{'all_selection_barrier':True,'records_sha256':digest(path),'manifest_sha256':digest(out/'manifest.json'),
        'record_count':len(records),'no_grade_based_row_selection':True})
    scores=[]
    for r in records:
        row={'case_id':r['case_id'],'arm':r['arm'],'status':r['status']}
        if r['status']=='COMPLETED':
            pre=suite.environment_type.model_validate(r['pre_environment']);post=suite.environment_type.model_validate(r['post_environment'])
            trace=[FunctionCall.model_validate(x) for x in r['functions_stack_trace']];parts=r['case_id'].split(':')
            row.update(utility=bool(suite._check_task_result(suite.get_user_task_by_id(parts[1]),r['model_output'],pre,post,trace)),
                injection_success=bool(suite._check_task_result(suite.get_injection_task_by_id(parts[2]),r['model_output'],pre,post,trace)))
        scores.append(row)
    totals={arm:{'enrolled':128,'scored':sum(s['status']=='COMPLETED' for s in scores if s['arm']==arm),
        'utility':sum(s.get('utility',False) for s in scores if s['arm']==arm),
        'injection_success':sum(s.get('injection_success',False) for s in scores if s['arm']==arm)} for arm in arms}
    summary={'phase':args.phase,'model':model,'arms':totals,'execution_errors':sum(r['status']=='ERROR' for r in records),
        'budget':budget.summary(),'new_owner_support_condition':True,'held_out':False}
    write(out/'native_scores.json',scores);write(out/'summary.json',summary)
    write(ROOT/('LATEST_'+args.phase.upper().replace('-','_')+'.json'),{'directory':str(out)})
    print(json.dumps({'run_directory':str(out),**summary}),flush=True)


if __name__=='__main__':main()
