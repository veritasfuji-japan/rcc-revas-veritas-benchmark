"""Prospective immediate-payment date input for a NEW local research condition.

Not V13 authority, not a production permission, and not clock attestation.
The trusted simulator harness owns the clock/key; neither is an exposed tool.
Only missing immediate-payment date checks can be fulfilled by this profile.
Original actor, policy, recipient, amount, lineage and native Bind checks remain.
"""
from __future__ import annotations
import copy
from datetime import datetime,timezone
import hashlib
import hmac
import json
import secrets

from agentdojo_constraint_resolver_v0_1 import validate_candidate
from original_request_authority_lineage_v1 import OriginalRequestEnvelope,validate_task15_from_original_request
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import RCCVeritasExecutor,jsonable,sha_json,PROTECTED_TOOLS

PROFILE='LOCAL_RESEARCH_IMMEDIATE_PAYMENT_UTC_DATE_V1'
ELIGIBLE=frozenset({3,4,11,15})


class PaymentDateSession:
    def __init__(self, case_id, request, task_id, clock=None):
        self.case_id=case_id;self.request=request;self.task_id=task_id
        self.clock=clock or (lambda:datetime.now(timezone.utc))
        self.key=secrets.token_bytes(32);self.ordinal=0;self.current=None
        self.captured=None;self.payment_committed=False;self.events=[]

    def issue(self,state):
        now=self.clock()
        if now.tzinfo is None: raise RuntimeError('AWARE_HARNESS_CLOCK_REQUIRED')
        now=now.astimezone(timezone.utc)
        self.ordinal+=1
        payload={'profile':PROFILE,'case_id':self.case_id,'task_id':self.task_id,
                 'original_request_sha256':sha_json(self.request),'pre_state_sha256':sha_json(state),
                 'proposal_ordinal':self.ordinal,'issued_at':now.isoformat(),'execution_date':now.date().isoformat()}
        raw=json.dumps(payload,sort_keys=True,separators=(',',':'))
        self.current=(raw,hmac.new(self.key,raw.encode(),hashlib.sha256).hexdigest())
        self.captured=None
        self.events.append({'event':'DATE_ISSUED_BEFORE_GENERATION','payload':payload})
        return payload['execution_date']

    def capture(self,candidate,state):
        if self.current is None or self.captured is not None or self.payment_committed: return False
        self.captured=sha_json(candidate.to_dict())
        self.events.append({'event':'CANDIDATE_CAPTURED','candidate_sha256':self.captured,'ordinal':self.ordinal})
        return self.verify(candidate,state)

    def verify(self,candidate,state):
        if self.current is None or self.captured!=sha_json(candidate.to_dict()) or self.payment_committed: return False
        raw,signature=self.current
        if not hmac.compare_digest(signature,hmac.new(self.key,raw.encode(),hashlib.sha256).hexdigest()): return False
        p=json.loads(raw);now=self.clock().astimezone(timezone.utc)
        issued=datetime.fromisoformat(p['issued_at'])
        return (0<=(now-issued).total_seconds()<300 and now.date().isoformat()==p['execution_date']
            and p['case_id']==self.case_id and p['task_id']==self.task_id
            and p['original_request_sha256']==sha_json(self.request)
            and p['pre_state_sha256']==sha_json(state)
            and set(candidate.arguments)=={'recipient','amount','subject','date'}
            and candidate.name=='send_money' and candidate.arguments['date']==p['execution_date'])


class ResearchDateExecutor(RCCVeritasExecutor):
    def __init__(self,*args,date_session,**kwargs):
        super().__init__(*args,**kwargs);self.date_session=date_session

    def call(self,candidate,apply):
        if candidate.name!='send_money' or self.user_task_id not in ELIGIBLE:
            return super().call(candidate,apply)
        from rveval.models import CandidateAction
        from rveval.integrations.boundary import GovernanceStop,CallResult
        from veritas_os.benchmarks.agentdojo_banking_adapter import AgentDojoBankingBindAdapter,freeze_agentdojo_candidate,build_agentdojo_benchmark_execution_intent
        from veritas_os.policy.bind_core import execute_bind_adjudication
        pre=copy.deepcopy(self.snapshot());before=sha_json(pre)
        captured=self.date_session.capture(candidate,pre)
        review=self.hook.review(candidate=candidate,context=copy.deepcopy(self.context(candidate)))
        if sha_json(self.snapshot())!=before: raise RuntimeError('STATE_CHANGED_DURING_REVIEW')
        if not review.get('dispatch_allowed_by_hook'): raise GovernanceStop({'stage':'RCC','review':review})
        adopted=CandidateAction(**review['candidate_to_dispatch'])
        self.hook.verify_dispatch(review,adopted)
        frozen=freeze_agentdojo_candidate(user_task_id=self.user_task_id,tool_name=adopted.name,arguments=adopted.arguments)

        def checks(fc,state):
            legacy=validate_candidate(user_task_id=self.user_task_id,tool_name=fc.tool_name,arguments=fc.arguments,trusted_prestate=state)
            if self.user_task_id==15:
                lineage=validate_task15_from_original_request(envelope=OriginalRequestEnvelope('banking',15,self.original_request),tool_name=fc.tool_name,arguments=fc.arguments,trusted_prestate=state)
                legacy={**legacy,**lineage}
            # Recognize only the existing missing-date branch, never an unknown
            # refusal or another task's authorization profile.
            recognized=legacy.get('supported_profile') is False and legacy.get('date_authority_present') is False
            bound=recognized and captured and self.date_session.verify(adopted,state)
            result={**legacy,'supported_profile':bound,'date_authority_present':bound,'exact_captured_candidate_bound':bound}
            self.journal('RESEARCH_DATE_CONSTRAINTS',result)
            return result

        box={};owner=self
        def mutate(name,args):
            if not self.date_session.verify(adopted,self.snapshot()): raise RuntimeError('DATE_BINDING_LOST_AT_NATIVE_SINK')
            value=apply(CandidateAction('tool_call',name=name,arguments=copy.deepcopy(args)))
            box['value']=value
            return isinstance(value,tuple) and len(value)==2 and value[1] is None

        def postcondition(name,args,initial):
            if sha_json(initial)!=before: return False
            expected=copy.deepcopy(pre);bank=expected['bank_account']
            identifiers=[t['id'] for t in bank['transactions']+bank['scheduled_transactions']]
            bank['transactions'].append({'id':max(identifiers,default=0)+1,'sender':bank['iban'],**copy.deepcopy(args),'recurring':False})
            return name=='send_money' and sha_json(self.snapshot())==sha_json(expected)

        class Guarded(AgentDojoBankingBindAdapter):
            def apply(adapter,intent,state):
                live=owner.snapshot()
                if not adapter.validate_authority(intent,live) or not all(adapter.validate_constraints(intent,live).values()) or not adapter.assess_runtime_risk(intent,live):
                    raise RuntimeError('NATIVE_BIND_ADMISSION_LOST_AT_DISPATCH')
                return super().apply(intent,state)

        adapter=Guarded(candidate=frozen,snapshot_reader=self.snapshot,mutation_executor=mutate,postcondition_checker=postcondition,authority_admitted=self.authority_admitted,constraint_validator=checks)
        digest=sha_json(review['rcc'])
        intent=build_agentdojo_benchmark_execution_intent(frozen,decision_id='rcc:'+digest,request_id='local-research:'+sha_json({'candidate':adopted.to_dict(),'pre':before,'ordinal':self.date_session.ordinal}),policy_snapshot_id='agentdojo-banking-clean-ab-v0.1',actor_identity='agentdojo:banking:benchmark-user',expected_state_fingerprint=before,decision_hash=digest,decision_ts=datetime.now(timezone.utc).isoformat())
        receipt=execute_bind_adjudication(execution_intent=intent,adapter=adapter,bind_ts=datetime.now(timezone.utc).isoformat(),append_trustlog=False)
        result=jsonable(receipt)
        self.journal('VERITAS_BIND_RECEIPT',{'candidate_sha256':sha_json(adopted.to_dict()),'receipt':result,'additional_research_profile':PROFILE})
        if result['final_outcome']=='COMMITTED':
            self.date_session.payment_committed=True
            return CallResult(value=box['value'],receipt={'native_bind_receipt':result,'rcc':review})
        if result['final_outcome'] in {'BLOCKED','ESCALATED','PRECONDITION_FAILED'}:
            raise GovernanceStop({'stage':'VERITAS_BIND','outcome':result['final_outcome'],'receipt':result})
        raise RuntimeError('NATIVE_BIND_INFRASTRUCTURE_FAILURE')


def make_research_runtime(*, arm, gate, task_id, case_id, request, journal, date_session, authority_admitted):
    from rveval.integrations.agentdojo import make_runtime_class,environment_snapshot
    from rveval.native_hook import NativeGovernanceHook
    from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import RCCOnlyExecutor
    hook=NativeGovernanceHook(gate)
    def emit(event,payload): journal.append({'event':event,'payload':jsonable(payload)})
    def factory(runtime,env):
        snapshot=lambda:environment_snapshot(env)
        context=lambda c:{'task':{'request':request,'suite':'banking'},'case_id':case_id,'user_task_id':task_id,'candidate_sha256':sha_json(c.to_dict())}
        if arm=='A': return RCCOnlyExecutor(hook,snapshot,context,emit)
        return ResearchDateExecutor(hook,snapshot,context,emit,user_task_id=task_id,authority_admitted=authority_admitted,original_request=request,date_session=date_session)
    return make_runtime_class(factory)
