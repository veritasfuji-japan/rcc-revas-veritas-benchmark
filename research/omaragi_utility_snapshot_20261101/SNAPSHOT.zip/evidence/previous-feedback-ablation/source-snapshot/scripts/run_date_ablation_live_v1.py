"""Explicitly approved, capped live ablation with the original native gate."""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import threading

ROOT = Path(__file__).resolve().parents[2]
OLD_RUN = Path('/Users/lua/Documents/Codex/2026-10-29/veritas-v13-audit/matched-engine-runs/20261030T044146423776Z-efd396ba')
sys.path[:0] = [str(ROOT/'benchmark'), str(ROOT/'agentdojo/src'),
               str(ROOT/'veritas-v13'), str(ROOT/'rcc-v13/external-eval/v0.3.9/src')]
from agentdojo.agent_pipeline.agent_pipeline import AgentPipeline, load_system_message
from agentdojo.agent_pipeline.basic_elements import InitQuery, SystemMessage
from agentdojo.agent_pipeline.tool_execution import ToolsExecutionLoop, ToolsExecutor
from agentdojo.functions_runtime import FunctionCall
from agentdojo.task_suite.load_suites import get_suite
from agentdojo.task_suite.task_suite import model_output_from_messages
from date_ablation_native_v1 import AblationLLM, AblationSession, MODES, MODE_DESCRIPTIONS
from research_provider_v1 import CumulativeBudget
from scripts.run_v13_matched_engine_v1 import MatchingWire
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import (
    MODEL_ID, build_pipeline, execute_trajectory, jsonable,
    load_rcc_gate, sha_json, verify_authority_fixture,
)

SCOPE = 'LIVE_PRELIMINARY_DATE_ABLATION_ORIGINAL_AUTHORITY_NO_DATE_ISSUANCE'


class AblationBudget(CumulativeBudget):
    def __init__(self, path):
        self.path = path
        assert path.exists(), 'COPIED_BUDGET_REQUIRED'
        with sqlite3.connect(path) as c:
            prior, extra, _ = c.execute('select prior_charged_micro,additional_limit_micro,prior_calls from ablation_authorization where id=1').fetchone()
            assert prior == 1078379 and extra == 3920000
            assert c.execute('select limit_micro from settings where id=1').fetchone()[0] == prior+extra

    def summary(self):
        with sqlite3.connect(self.path) as c:
            charged, held, calls = c.execute('select sum(charged),sum(reserved),count(*) from calls').fetchone()
            prior, extra, prior_calls = c.execute('select prior_charged_micro,additional_limit_micro,prior_calls from ablation_authorization where id=1').fetchone()
        return {'prior_spend_usd': prior/1e6, 'new_experiment_charged_usd': (charged-prior)/1e6,
                'uncertain_or_reserved_usd': held/1e6, 'additional_limit_usd': extra/1e6,
                'cumulative_estimated_usd': charged/1e6, 'cumulative_cap_usd': (prior+extra)/1e6,
                'new_provider_calls': calls-prior_calls}


class CircuitWire(MatchingWire):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.failed = threading.Event()

    def create(self, **kwargs):
        if self.failed.is_set():
            raise RuntimeError('PROVIDER_CIRCUIT_HALTED_NO_RETRY')
        try:
            return super().create(**kwargs)
        except Exception:
            self.failed.set()
            raise


def execute_optimization(suite, task, initial, case_id, mode, wire, actor):
    env = initial.model_copy(deep=True)
    session = AblationSession(mode=MODES[mode], case_id=case_id, task=task, env=env,
        gate=load_rcc_gate(ROOT/'rcc-v13'), suite=suite, actor_fixture_verified=actor)
    llm = AblationLLM(wire, session)
    pipeline = AgentPipeline([SystemMessage(load_system_message(None)), InitQuery(), llm,
                              ToolsExecutionLoop([ToolsExecutor(), llm])])
    messages, output, status, failure, attempts = [], None, 'COMPLETED', None, 0
    try:
        for _ in range(3):
            attempts += 1
            _, _, env, messages, _ = pipeline.query(task.PROMPT, session.runtime, env)
            output = model_output_from_messages(messages)
            if output is not None:
                break
        output = session.complete_from_source(env, output or [])
    except Exception as exc:
        status, failure = 'ERROR', type(exc).__name__
    return {'case_id': case_id, 'arm': mode, 'status': status, 'failure': failure,
        'pre_environment': session.initial, 'post_environment': env.model_dump(mode='json'),
        'pre_state_sha256': sha_json(session.initial), 'post_state_sha256': sha_json(env.model_dump(mode='json')),
        'model_output': jsonable(output or []), 'model_history': jsonable(messages),
        'functions_stack_trace': session.final_trace(), 'native_calls': session.calls,
        'governance_journal': session.journal, 'date_refusals': session.date_authority.events,
        'source_events': session.events, 'no_progress_stop': session.no_progress,
        'pipeline_outer_attempts': attempts, 'date_issued': False,
        'independent_date_authority_admitted': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=6)
    args = parser.parse_args()
    authorization = json.loads((ROOT/'API_AUTHORIZATION.json').read_text())
    assert authorization['human_authorization'] == '승인 — 기존 키로 추가 US$3.92 이내'
    assert authorization['arms'] == ['A', 'B', 'F', 'S', 'N']
    assert authorization['max_new_cost_usd'] == 3.92 and authorization['old_v13_dispatch_reused'] is False
    old_manifest = json.loads((OLD_RUN/'manifest.json').read_text())
    for name in ('scripts/agentdojo_clean_ab_canonical_final_runner_v2_8.py',
                 'scripts/agentdojo_final_runner_integration_v0_1.py',
                 'scripts/agentdojo_openai_frozen_adapter_v0_1.py',
                 'governance_feedback_v1.py', 'trusted_proposal_repair_v1.py', 'research_source_planner_v1.py'):
        assert hashlib.sha256((ROOT/'benchmark'/name).read_bytes()).hexdigest() == old_manifest['source_hashes'][name]
    out = ROOT/'live-runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True, exist_ok=False)
    (out/'provider').mkdir()
    (out/'cases').mkdir()
    originals = [json.loads(x) for x in (OLD_RUN/'execution_records.jsonl').read_text().splitlines()]
    cases = [r for r in originals if r['arm'] == 'B']
    assert len(cases) == 128
    source_files = ['date_ablation_native_v1.py', 'scripts/run_date_ablation_live_v1.py',
        'scripts/run_v13_matched_engine_v1.py', 'research_provider_v1.py',
        'governance_feedback_v1.py', 'trusted_proposal_repair_v1.py', 'research_source_planner_v1.py',
        'agentdojo_constraint_resolver_v0_1.py', 'original_request_authority_lineage_v1.py',
        'scripts/agentdojo_clean_ab_canonical_final_runner_v2_8.py']
    manifest = {'classification': 'NEW_PROVIDER_PRELIMINARY_ABLATION_EXPOSED_128_CASES',
        'scope': SCOPE, 'model': MODEL_ID, 'arms': authorization['arms'], 'cases_per_arm': 128,
        'refusal_aliases': {'D_DENIED': 'B', 'C_STRICT': 'N'},
        'arm_definitions': {a: MODE_DESCRIPTIONS[a] for a in MODES},
        'source_sha256': {p: hashlib.sha256((ROOT/'benchmark'/p).read_bytes()).hexdigest() for p in source_files},
        'authorization_sha256': hashlib.sha256((ROOT/'API_AUTHORIZATION.json').read_bytes()).hexdigest(),
        'workers': args.workers, 'date_issuance_allowed': False,
        'independent_date_issuer_approved': False, 'historical_C_is_not_a_new_run': True,
        'model_policy': {'temperature': 0, 'max_completion_tokens': 1024, 'automatic_retries': False,
                         'wire': 'original developer content blocks and YAML tools', 'max_tool_iters': 15,
                         'max_outer_attempts': 3},
        'held_out': False, 'independent_external_replication': False, 'external_financial_effects': False}
    (out/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    for name in source_files:
        target = out/'source-snapshot'/name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT/'benchmark'/name).read_bytes())
    budget = AblationBudget(ROOT/'ablation-api-budget.sqlite')
    wire = CircuitWire(out/'provider', budget)
    suite = get_suite('v1.2.2', 'banking')
    actor = verify_authority_fixture()

    def execute(case, mode):
        cid = case['case_id']
        wire.context.case_id, wire.context.arm = cid, mode
        task = suite.get_user_task_by_id(cid.split(':')[1])
        env = suite.environment_type.model_validate(case['pre_environment'])
        assert sha_json(env.model_dump(mode='json')) == case['pre_state_sha256']
        if mode in ('A', 'B'):
            result = execute_trajectory(suite=suite, user_task=task,
                injection_task=suite.get_injection_task_by_id(cid.split(':')[2]), initial_env=env,
                arm=mode, pipeline=build_pipeline(wire), rcc_gate=load_rcc_gate(ROOT/'rcc-v13'),
                case_id=cid, authority_admitted=actor)
            result['date_issued'] = False
        else:
            result = execute_optimization(suite, task, env, cid, mode, wire, actor)
        result['scope'] = SCOPE
        (out/'cases'/(cid.replace(':', '_')+'_'+mode+'.json')).write_text(json.dumps(result, sort_keys=True, ensure_ascii=False)+'\n')
        return result

    print(json.dumps({'run_directory': str(out), 'paid_trajectories': 640, 'budget': budget.summary()}), flush=True)
    records = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(execute, case, mode) for case in cases for mode in authorization['arms']]
        for f in as_completed(futures):
            records.append(f.result())
            if len(records) % 32 == 0:
                print(json.dumps({'finished': len(records), 'total': 640,
                    'errors': sum(r['status'] != 'COMPLETED' for r in records), 'budget': budget.summary()}), flush=True)
    # These are declared treatment aliases, not independently generated outputs.
    aliases = []
    for record in records:
        alias = {'B': 'D_DENIED', 'N': 'C_STRICT'}.get(record['arm'])
        if alias:
            clone = copy.deepcopy(record)
            clone['arm'] = alias
            clone['treatment_alias_of'] = record['arm']
            clone['classification'] = 'AUTHORITY_REFUSAL_TREATMENT_ALIAS_NOT_INDEPENDENT_MODEL_RUN'
            clone['alias_new_provider_calls'] = 0
            aliases.append(clone)
    all_records = sorted(records+aliases, key=lambda r: (r['case_id'], r['arm']))
    path = out/'execution_records.jsonl'
    path.write_text(''.join(json.dumps(r, sort_keys=True, ensure_ascii=False)+'\n' for r in all_records))
    lock = {'record_count': len(all_records), 'independently_generated_trajectories': 640,
        'declared_alias_trajectories': len(aliases), 'all_selection_barrier': True,
        'records_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'manifest_sha256': hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()}
    (out/'final-lock.json').write_text(json.dumps(lock, indent=2)+'\n')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == lock['records_sha256']
    scores = []
    for record in all_records:
        score = {'case_id': record['case_id'], 'arm': record['arm'], 'status': record['status']}
        if record['status'] == 'COMPLETED':
            parts = record['case_id'].split(':')
            pre = suite.environment_type.model_validate(record['pre_environment'])
            post = suite.environment_type.model_validate(record['post_environment'])
            trace = [FunctionCall.model_validate(c) for c in record['functions_stack_trace']]
            score.update(utility=bool(suite._check_task_result(suite.get_user_task_by_id(parts[1]), record['model_output'], pre, post, trace)),
                injection_success=bool(suite._check_task_result(suite.get_injection_task_by_id(parts[2]), record['model_output'], pre, post, trace)))
        scores.append(score)
    by_case = {}
    for score in scores:
        by_case.setdefault(score['case_id'], {})[score['arm']] = score
    historical_scores = {(r['case_id'], r['arm']): r for r in json.loads((OLD_RUN/'native_scores.json').read_text())}
    summary = {'classification': manifest['classification'], 'model': MODEL_ID,
        'independently_generated_trajectories': 640, 'alias_trajectories': len(aliases),
        'execution_errors': sum(r['status'] != 'COMPLETED' for r in records), 'budget': budget.summary(), 'arms': {}}
    for mode in ['A', 'B', 'F', 'S', 'N', 'D_DENIED', 'C_STRICT']:
        rows = [s for s in scores if s['arm'] == mode]
        valid = [s for s in rows if s['status'] == 'COMPLETED']
        stats = {'enrolled': len(rows), 'scored': len(valid), 'utility': sum(s['utility'] for s in valid),
                 'injection_success': sum(s['injection_success'] for s in valid)}
        for reference in ('A', 'B'):
            for fresh in (True, False):
                label = ('fresh_' if fresh else 'archived_')+reference
                comparisons = [(s, by_case[s['case_id']][reference] if fresh else historical_scores[s['case_id'], reference]) for s in valid]
                eligible = [(s, ref) for s, ref in comparisons if ref.get('status', 'COMPLETED') == 'COMPLETED']
                stats['gains_vs_'+label] = sum(s['utility'] and not ref['utility'] for s, ref in eligible)
                stats['regressions_vs_'+label] = sum(ref['utility'] and not s['utility'] for s, ref in eligible)
        if mode in manifest['refusal_aliases']:
            stats['not_independent_alias_of'] = manifest['refusal_aliases'][mode]
        summary['arms'][mode] = stats
    (out/'native_scores.json').write_text(json.dumps(scores, indent=2)+'\n')
    (out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    (ROOT/'LATEST_LIVE.json').write_text(json.dumps({'directory': str(out)}, indent=2)+'\n')
    print(json.dumps({'run_directory': str(out), 'summary': summary}, indent=2), flush=True)


if __name__ == '__main__':
    main()
