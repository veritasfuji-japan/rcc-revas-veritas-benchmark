"""Shared new authority inputs; optional receipt/source optimization package."""
from __future__ import annotations
import copy
from collections import Counter

from darwin_hinton_feedback_v2 import with_feedback
from date_ablation_native_v1 import no_date_hint
from immutable_effect_anchor_v3 import with_effect_anchor
from owner_approved_research_runtime_v1 import ScopeSession,make_owner_runtime
from research_source_planner_v1 import next_source_proposal
from trusted_proposal_repair_v1 import propose,monthly_query,subject_spending_query,monthly_spending_answer,subject_spending_answer
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import sha_json,jsonable
from scripts.agentdojo_final_runner_integration_v0_1 import FrozenAgentDojoOpenAIPipeline


class OwnerResearchSession:
    def __init__(self,*,arm,row,task,suite,gate,actor,enrollment,memory):
        self.arm,self.request=arm,task.PROMPT
        self.initial=copy.deepcopy(row['pre_environment'])
        self.scope=ScopeSession(enrollment,row['case_id'],arm,self.request,self.initial)
        self.journal=[];self.calls=[];self.events=[];self.no_progress=False;self.repeats=Counter()
        self.engine=arm=='E_SUPPORT'
        base=make_owner_runtime(gate,int(task.ID.rsplit('_',1)[1]),row['case_id'],self.request,self.journal,actor,self.scope)
        if self.engine:base=with_feedback(base,self.journal,memory)
        owner=self
        class Recorded(base):
            def run_function(runtime,env,function,kwargs,raise_on_error=False):
                before=env.model_dump(mode='json')
                args,evidence=(propose(owner.request,function,kwargs,before) if owner.engine else (copy.deepcopy(kwargs),[]))
                start=len(owner.journal)
                value,error=super().run_function(env,function,args,raise_on_error=raise_on_error)
                after=env.model_dump(mode='json')
                owner.calls.append({'function':function,'args':copy.deepcopy(args),'id':None,'placeholder_args':None,
                    'raw_args':copy.deepcopy(kwargs),'source_evidence':evidence,
                    'pre_state_sha256':sha_json(before),'post_state_sha256':sha_json(after),
                    'error':error,'journal_range':[start,len(owner.journal)]})
                fingerprint=sha_json({'function':function,'args':args,'state':after,'error':error})
                owner.repeats[fingerprint]+=1
                if owner.engine and owner.repeats[fingerprint]>=3:owner.no_progress=True
                return value,error
        runtime=Recorded(suite.tools)
        if self.engine:
            def stop():owner.no_progress=True
            runtime=with_effect_anchor(type(runtime),self.journal,self.request,self.initial,
                int(task.ID.rsplit('_',1)[1]),stop)(suite.tools)
        self.runtime=runtime

    def complete(self,env,output):
        if not self.engine:return output
        if monthly_query(self.request) or subject_spending_query(self.request):
            value,error=self.runtime.run_function(env,'get_most_recent_transactions',{'n':max(1,len(env.bank_account.transactions))})
            if error is None:
                value=jsonable(value)
                answer=monthly_spending_answer(self.request,value,env.bank_account.iban) or subject_spending_answer(self.request,value,env.bank_account.iban)
                if answer is not None:output=[{'type':'text','content':answer}]
        for _ in range(8):
            date=self.scope.scope['proposed_operation']['args']['date'] if self.scope.scope else None
            proposal=next_source_proposal(self.request,self.initial,env.model_dump(mode='json'),date,payment_committed=self.scope.payment_committed)
            if proposal is None and self.scope.scope and not self.scope.payment_committed:
                proposal=self.scope.scope['proposed_operation']
            if proposal is None:break
            if proposal['function']=='send_money' and not self.scope.scope:
                self.events.append({'event':'PAYMENT_NOT_IN_OWNER_SCOPE_NO_DISPATCH'});break
            _,error=self.runtime.run_function(env,proposal['function'],proposal['args'])
            self.events.append({'event':'SOURCE_OR_OWNER_BOUND_PROPOSAL','function':proposal['function'],'error':error,
                'authority_source':'actual owner decision and frozen proposal for additional payments; original Native for other effects'})
            if error:break
            output=[{'type':'text','content':'The stated admitted effect is recorded in the Native execution receipts. Read the receipts for which request parts completed.'}]
        return output

    def trace(self):
        return [{k:c[k] for k in ('function','args','id','placeholder_args')} for c in self.calls]


class OwnerResearchLLM:
    def __init__(self,wire,session,memory):
        self.base=FrozenAgentDojoOpenAIPipeline(wire);self.session=session;self.memory=memory

    def query(self,query,runtime,env,messages=(),extra_args=None):
        if self.session.no_progress:
            stop={'role':'assistant','content':[{'type':'text','content':'Stopped after repeated identical tool calls without progress.'}],'tool_calls':None}
            return query,runtime,env,[*messages,stop],dict(extra_args or {})
        prepared=copy.deepcopy(messages)
        prepared[0]['content'][0]['content']+='\n'+self.session.scope.shared_model_context()
        if self.session.engine:
            prepared[0]['content'][0]['content']+='\n'+no_date_hint()+'\n'+self.memory.learned_hint()
        result=self.base.query(query,runtime,env,prepared,extra_args or {})
        history=list(result[3]);history[0]=messages[0]
        return result[0],result[1],result[2],history,result[4]
