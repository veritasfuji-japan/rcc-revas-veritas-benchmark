"""Offline actual-Native control: same candidate/state for both new arms.

Uses marked TEST approval fixtures, never live-model grants or official scores.
Also preserves the original gate's rejection for the identical candidate.
"""
import copy
from datetime import datetime,timezone
import json
from pathlib import Path
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'benchmark'),str(ROOT/'agentdojo/src'),str(ROOT/'veritas-v13'),str(ROOT/'rcc-v13/external-eval/v0.3.9/src')]


def offline(event,args):
    if event in {'socket.connect','socket.connect_ex','socket.getaddrinfo'}:raise RuntimeError('OFFLINE_NATIVE_CONTROL')


sys.addaudithook(offline)
from agentdojo.task_suite.load_suites import get_suite
from owner_approved_research_runtime_v1 import OwnerEnrollment,ScopeSession,make_owner_runtime
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import load_rcc_gate,verify_authority_fixture,sha_json,make_runtime_class


def main():
    proposal=json.loads((ROOT/'RESEARCH_APPROVAL_PROPOSAL.json').read_text())
    old=Path('/Users/lua/Documents/Codex/2026-11-01/veritas-runtime-repair-round2/runs/20261101T172120315038Z-mini-d4')
    rows={r['case_id']:r for r in (json.loads(x) for x in (old/'execution_records.jsonl').read_text().splitlines()) if r['arm']=='N'}
    suite=get_suite('v1.2.2','banking');gate=load_rcc_gate(ROOT/'rcc-v13');actor=verify_authority_fixture()
    fields=('authority_check_result','constraint_check_result','risk_check_result','drift_check_result','failed_predicates','missing_predicates','final_outcome')
    results=[]
    with tempfile.TemporaryDirectory() as temporary:
        enrollment=OwnerEnrollment('nano-support-v1',proposal['proposed_scopes'],
            {'owner_review_approved':True,'decision_source':{'source_record_sha256':'TEST_FIXTURE_NOT_REAL_APPROVAL'}},
            Path(temporary)/'test.sqlite',clock=lambda:datetime(2026,11,1,20,tzinfo=timezone.utc),test_only=True)
        for scope in proposal['proposed_scopes']:
            cid=scope['case_id'];row=rows[cid];task=suite.get_user_task_by_id(cid.split(':')[1]);tid=int(task.ID.rsplit('_',1)[1]);outcomes={}
            for arm in ('B_SUPPORT','E_SUPPORT','LEGACY_B'):
                env=suite.environment_type.model_validate(row['pre_environment']);journal=[]
                if arm=='LEGACY_B':
                    runtime=make_runtime_class(arm='B',rcc_gate=gate,user_task_id=tid,case_id=cid,prompt=task.PROMPT,
                        journal_rows=journal,authority_admitted=actor)(suite.tools)
                else:
                    session=ScopeSession(enrollment,cid,arm,task.PROMPT,row['pre_environment'])
                    runtime=make_owner_runtime(gate,tid,cid,task.PROMPT,journal,actor,session)(suite.tools)
                operation=scope['proposed_operation'];_,error=runtime.run_function(env,operation['function'],copy.deepcopy(operation['args']))
                native=[e['payload'] for e in journal if e['event']=='VERITAS_BIND_RECEIPT']
                outcomes[arm]={'native_checks':[{k:e['receipt'].get(k) for k in fields} for e in native],
                    'candidate_hashes':[e['candidate_sha256'] for e in native],
                    'post_state_sha256':sha_json(env.model_dump(mode='json')),'error':error}
            assert outcomes['B_SUPPORT']['native_checks']==outcomes['E_SUPPORT']['native_checks']
            assert outcomes['B_SUPPORT']['candidate_hashes']==outcomes['E_SUPPORT']['candidate_hashes']
            assert outcomes['B_SUPPORT']['post_state_sha256']==outcomes['E_SUPPORT']['post_state_sha256']
            assert outcomes['B_SUPPORT']['native_checks'][0]['final_outcome']=='COMMITTED'
            assert outcomes['LEGACY_B']['native_checks'][0]['final_outcome']=='BLOCKED'
            assert outcomes['LEGACY_B']['post_state_sha256']==sha_json(row['pre_environment'])
            results.append({'case_id':cid,'pre_state_sha256':scope['original_injected_prestate_sha256'],'outcomes':outcomes})
    dest=ROOT/'approved-controls'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');dest.mkdir(parents=True)
    (dest/'controls.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in results))
    summary={'classification':'SAME_CANDIDATE_NATIVE_TEST_CONTROL_NOT_MODEL_UTILITY_OR_REAL_AUTHORITY_ATTESTATION',
        'same_candidate_and_prestate_pairs':len(results),'new_arm_check_or_poststate_differences':0,
        'original_legacy_refusals_preserved':len(results),'test_fixture_new_support_commits_per_arm':len(results),
        'difference_attributed_to':'explicit new authority/support condition, not optimization','provider_calls':0,'official_scores':None}
    (dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (ROOT/'LATEST_OWNER_NATIVE_CONTROLS.json').write_text(json.dumps({'directory':str(dest)},indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
