"""Transient authorized credential and durable cumulative research budget.

No credential is saved. The explicit current-chat user key is read locally into
process memory, sent only to the official OpenAI endpoint, and never logged.
"""
from __future__ import annotations
import json
import math
import os
from pathlib import Path
import re
import sqlite3
import threading
import uuid

PRICES = {
    'gpt-5-nano-2025-08-07': (0.05, 0.005, 0.40),
    'gpt-4.1-mini-2025-04-14': (0.40, 0.10, 1.60),
}


def authorized_key():
    thread=os.environ.get('CODEX_THREAD_ID')
    if not thread: raise RuntimeError('CURRENT_AUTHORIZED_THREAD_REQUIRED')
    db=sqlite3.connect('file:/Users/lua/.codex/thread_history_1.sqlite?mode=ro',uri=True)
    try:
        rows=db.execute("select item_json from thread_items where thread_id=? and item_type='userMessage' order by rollout_ordinal desc limit 50",(thread,))
        for (raw,) in rows:
            matches=re.findall(r'sk-proj-[A-Za-z0-9_-]{40,}',raw)
            if len(matches)==1: return matches[0]
    finally: db.close()
    raise RuntimeError('EXPLICITLY_SUPPLIED_CREDENTIAL_NOT_AVAILABLE')


class CumulativeBudget:
    def __init__(self, path: Path):
        self.path=path
        with sqlite3.connect(path) as c:
            c.execute('create table if not exists calls (id text primary key, model text, reserved integer, charged integer, status text, usage text)')
            c.execute('create table if not exists settings (id integer primary key, limit_micro integer)')
            c.execute('insert or ignore into settings values (1,5000000)')
            # The successful credential smoke request occurred before this ledger.
            c.execute('insert or ignore into calls values (?,?,?,?,?,?)',('credential-preflight','gpt-5-nano-2025-08-07',0,5,'complete','{}'))

    def reserve(self, model, request, output_limit):
        if model not in PRICES: raise RuntimeError('UNAPPROVED_MODEL')
        # UTF-8 byte count bounds tokenizer bytes, with generous chat/tool framing.
        upper_input=len(json.dumps(request,ensure_ascii=False).encode())+8192
        price=PRICES[model]
        amount=math.ceil(upper_input*price[0]+output_limit*price[2])
        identity=uuid.uuid4().hex
        with sqlite3.connect(self.path,timeout=30,isolation_level=None) as c:
            c.execute('begin immediate')
            spent=c.execute('select coalesce(sum(charged+reserved),0) from calls').fetchone()[0]
            limit=c.execute('select limit_micro from settings where id=1').fetchone()[0]
            if spent+amount>limit:
                c.rollback();raise RuntimeError('CUMULATIVE_USD_5_LIMIT')
            c.execute('insert into calls values (?,?,?,?,?,?)',(identity,model,amount,0,'reserved','{}'))
            c.commit()
        return identity

    def settle(self, identity, model, usage):
        price=PRICES[model]
        cached=(usage.get('prompt_tokens_details') or {}).get('cached_tokens',0)
        charged=math.ceil(max(0,usage['prompt_tokens']-cached)*price[0]+cached*price[1]+usage['completion_tokens']*price[2])
        with sqlite3.connect(self.path) as c:
            reserved=c.execute('select reserved from calls where id=?',(identity,)).fetchone()[0]
            c.execute('update calls set charged=?,reserved=0,status=?,usage=? where id=?',(charged,'complete',json.dumps(usage),identity))
        if charged>reserved: raise RuntimeError('USAGE_EXCEEDED_CONSERVATIVE_RESERVATION')

    def uncertain(self, identity):
        with sqlite3.connect(self.path) as c: c.execute("update calls set status='uncertain_no_auto_retry' where id=?",(identity,))

    def summary(self):
        with sqlite3.connect(self.path) as c:
            charged,held,count=c.execute('select coalesce(sum(charged),0),coalesce(sum(reserved),0),count(*) from calls').fetchone()
        return {'limit_usd':5,'estimated_charged_usd':charged/1e6,'uncertain_or_reserved_usd':held/1e6,'recorded_calls':count}


class ResearchProvider:
    def __init__(self, model, budget, directory):
        from openai import OpenAI
        if model not in PRICES: raise RuntimeError('UNAPPROVED_MODEL')
        self.model=model;self.budget=budget;self.directory=directory
        self.client=OpenAI(api_key=authorized_key(),base_url='https://api.openai.com/v1',max_retries=0,timeout=60)
        self.lock=threading.Lock();self.ordinal=0

    def create(self, messages, tools):
        limit=2048 if self.model.startswith('gpt-5-nano') else 1024
        args={'model':self.model,'messages':messages,'tools':tools,'tool_choice':'auto','parallel_tool_calls':False,'max_completion_tokens':limit,'store':False}
        if self.model.startswith('gpt-5-nano'): args['reasoning_effort']='minimal'
        else: args['temperature']=0.0
        identity=self.budget.reserve(self.model,args,limit)
        with self.lock:
            ordinal=self.ordinal;self.ordinal+=1
        prefix=self.directory/f'{ordinal:05d}-{identity}'
        prefix.with_suffix('.request.json').write_text(json.dumps(args,ensure_ascii=False,sort_keys=True)+'\n')
        try: response=self.client.chat.completions.create(**args)
        except Exception as exc:
            self.budget.uncertain(identity)
            safe={'exception_type':type(exc).__name__,'http_status':getattr(exc,'status_code',None),'automatic_retry':False}
            prefix.with_suffix('.error.json').write_text(json.dumps(safe)+'\n')
            raise RuntimeError('PROVIDER_REQUEST_FAILED_NO_AUTOMATIC_RETRY') from None
        data=response.model_dump(mode='json')
        prefix.with_suffix('.response.json').write_text(json.dumps(data,ensure_ascii=False,sort_keys=True)+'\n')
        if not response.usage: self.budget.uncertain(identity);raise RuntimeError('USAGE_MISSING')
        self.budget.settle(identity,self.model,response.usage.model_dump(mode='json'))
        if response.choices[0].finish_reason=='length': raise RuntimeError('INCOMPLETE_OUTPUT_NO_AUTOMATIC_RETRY')
        return response
