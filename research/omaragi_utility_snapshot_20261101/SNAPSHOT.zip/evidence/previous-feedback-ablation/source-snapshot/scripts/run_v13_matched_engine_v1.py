"""Fresh authorized local comparison: exact V13 base path, frozen engine added.

A = original RCC; B = original RCC+VERITAS; C = developed engine.
No consumed V13 dispatch authorization is reused. This is an in-memory research
run authorized by the current user, inside the existing cumulative US$5 cap.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
import uuid
import zipfile

ROOT=Path(__file__).resolve().parents[2];BENCH=ROOT/'benchmark'
sys.path[:0]=[str(BENCH),str(ROOT/'agentdojo/src'),str(ROOT/'veritas-v13'),str(ROOT/'rcc-v13/external-eval/v0.3.9/src')]
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import (
    MODEL_ID,MAX_COMPLETION_TOKENS,OPENAI_TIMEOUT_SECONDS,build_pipeline,
    execute_trajectory,load_rcc_gate,verify_authority_fixture,jsonable,sha_json)
from research_provider_v1 import authorized_key,CumulativeBudget
from matched_engine_adapter_v1 import EngineSession,EngineLLM,frozen_engine_hint
from agentdojo.agent_pipeline.agent_pipeline import AgentPipeline,load_system_message
from agentdojo.agent_pipeline.basic_elements import InitQuery,SystemMessage
from agentdojo.agent_pipeline.tool_execution import ToolsExecutionLoop,ToolsExecutor
from agentdojo.task_suite.load_suites import get_suite
from agentdojo.task_suite.task_suite import model_output_from_messages,functions_stack_trace_from_messages
from agentdojo.functions_runtime import FunctionCall

SCOPE='V13_MATCHED_BASE_HARNESS_FROZEN_ENGINE_INTERVENTION_V1'
ENGINE_FILES=['governance_feedback_v1.py','trusted_proposal_repair_v1.py','research_payment_date_v1.py','research_source_planner_v1.py']
ENGINE_COMMIT='6a05674a9973fc9f7d32ed39f64ccc76d08ff0ca'


class MatchingWire:
    def __init__(self,directory,budget,client=None):
        if client is None:
            from openai import OpenAI
            client=OpenAI(api_key=authorized_key(),base_url='https://api.openai.com/v1',max_retries=0,timeout=OPENAI_TIMEOUT_SECONDS)
        self.base=client;self.budget=budget;self.directory=Path(directory);self.context=threading.local()
        self.chat=SimpleNamespace(completions=self)

    def create(self,**kwargs):
        if kwargs.get('model')!=MODEL_ID or kwargs.get('temperature')!=0.0:
            raise RuntimeError('V13_MODEL_CONFIGURATION_DRIFT')
        if any(x in kwargs for x in ('parallel_tool_calls','reasoning_effort','seed')):
            raise RuntimeError('V13_UNREQUESTED_SAMPLING_OVERRIDE')
        # This is the same augmentation as original BudgetedCompletions.create.
        kwargs['max_completion_tokens']=MAX_COMPLETION_TOKENS
        identity=self.budget.reserve(MODEL_ID,kwargs,MAX_COMPLETION_TOKENS)
        prefix=self.directory/identity
        prefix.with_suffix('.request.json').write_text(json.dumps(kwargs,sort_keys=True,ensure_ascii=False)+'\n')
        tag={'case_id':getattr(self.context,'case_id','TEST'),'arm':getattr(self.context,'arm','TEST')}
        started=time.monotonic()
        try: response=self.base.chat.completions.create(**kwargs)
        except Exception as exc:
            self.budget.uncertain(identity)
            prefix.with_suffix('.error.json').write_text(json.dumps({**tag,'exception_type':type(exc).__name__,'http_status':getattr(exc,'status_code',None),'automatic_retry':False})+'\n')
            raise RuntimeError('PROVIDER_REQUEST_FAILED_NO_AUTOMATIC_RETRY') from None
        prefix.with_suffix('.response.json').write_text(json.dumps(response.model_dump(mode='json'),sort_keys=True,ensure_ascii=False)+'\n')
        prefix.with_suffix('.receipt.json').write_text(json.dumps({**tag,'latency_seconds':time.monotonic()-started})+'\n')
        if response.usage is None:
            self.budget.uncertain(identity);raise RuntimeError('PROVIDER_USAGE_MISSING')
        self.budget.settle(identity,MODEL_ID,response.usage.model_dump(mode='json'))
        return response


def execute_engine(suite,task,initial,case_id,wire,authority):
    env=initial.model_copy(deep=True);pre=env.model_dump(mode='json')
    engine=EngineSession(case_id,task,env,load_rcc_gate(ROOT/'rcc-v13'),suite,authority)
    llm=EngineLLM(wire,engine)
    pipeline=AgentPipeline([SystemMessage(load_system_message(None)),InitQuery(),llm,ToolsExecutionLoop([ToolsExecutor(),llm])])
    messages=[];output=None;status='COMPLETED';failure=None
    try:
        # Preserve V13's outer attempt/loop contract; no scorer is involved.
        for _ in range(3):
            _,_,env,messages,_=pipeline.query(task.PROMPT,engine.runtime,env)
            output=model_output_from_messages(messages)
            if output is not None: break
        output=engine.complete_from_source(env,output or [])
    except Exception as exc:
        status='ERROR';failure=type(exc).__name__
    return {'case_id':case_id,'arm':'C','status':status,'failure':failure,'pre_environment':pre,
        'post_environment':env.model_dump(mode='json'),'pre_state_sha256':sha_json(pre),
        'post_state_sha256':sha_json(env.model_dump(mode='json')),'model_output':jsonable(output or []),
        'functions_stack_trace':engine.trace,'model_proposals_trace':[jsonable(x) for x in functions_stack_trace_from_messages(messages)],
        'model_history':jsonable(messages),'governance_journal':engine.journal,
        'proposal_adoptions':engine.adoptions,'date_issuance_events':engine.date.events,
        'engine_no_progress_stop':engine.no_progress}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--workers',type=int,default=6)
    args=parser.parse_args()
    # Only the adapter/wire path may change; the developed engine stays fixed.
    for name in ENGINE_FILES:
        frozen=subprocess.check_output(['git','show',ENGINE_COMMIT+':'+name],cwd=BENCH)
        assert (BENCH/name).read_bytes()==frozen,'ENGINE_SOURCE_DRIFT:'+name
    out=ROOT/'matched-engine-runs'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True);(out/'provider').mkdir();(out/'cases').mkdir()
    with zipfile.ZipFile(ROOT/'v13-original.zip') as z:
        records=[json.loads(x) for x in z.read('results/agentdojo-clean-ab-final-v13/execution_records.jsonl').splitlines()]
    cases=[r for r in records if r['arm']=='B'];assert len(cases)==128
    files=ENGINE_FILES+['matched_engine_adapter_v1.py','research_provider_v1.py','scripts/run_research_models_v1.py',
        'scripts/run_v13_matched_engine_v1.py','scripts/agentdojo_clean_ab_canonical_final_runner_v2_8.py',
        'scripts/agentdojo_final_runner_integration_v0_1.py','scripts/agentdojo_openai_frozen_adapter_v0_1.py']
    manifest={'scope':SCOPE,'model':MODEL_ID,'arms':'ABC','candidate_arm':'C','case_count':128,
        'scorable_terminal_states':['COMPLETED'],'held_out':False,'external_effects':False,
        'model_config':{'temperature':0.0,'max_completion_tokens':MAX_COMPLETION_TOKENS,
            'parallel_tool_calls':'OMITTED_AS_V13','automatic_retry':False,'timeout_seconds':OPENAI_TIMEOUT_SECONDS},
        'base_harness':'V13 original build_pipeline, developer-role content blocks, YAML tools, default 15 tool iterations, 3 outer attempts',
        'arms_definition':{'A':'V13 original RCC','B':'V13 original RCC+VERITAS','C':'same base with developed source/feedback/date engine'},
        'engine_frozen_commit':ENGINE_COMMIT,'engine_prompt':frozen_engine_hint(),
        'intentional_engine_intervention':'C only: source proposals/calculations, typed feedback, no-progress controller, trusted simulator host-UTC date profile; native date admission changes are part of the engine, not identical frozen V13 authority inputs',
        'fresh_authorization':'Current user explicitly requests matched baseline/model conditions while retaining our engine; remaining cumulative USD5 budget',
        'old_single_use_dispatch_reused':False,'source_hashes':{p:hashlib.sha256((BENCH/p).read_bytes()).hexdigest() for p in files}}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    for name in files:
        p=out/'source-snapshot'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((BENCH/name).read_bytes())
    budget=CumulativeBudget(ROOT/'research-api-budget.sqlite');wire=MatchingWire(out/'provider',budget)
    suite=get_suite('v1.2.2','banking');authority=verify_authority_fixture()
    def execute(case,arm):
        cid=case['case_id'];wire.context.case_id=cid;wire.context.arm=arm
        task=suite.get_user_task_by_id(cid.split(':')[1]);env=suite.environment_type.model_validate(case['pre_environment'])
        assert sha_json(env.model_dump(mode='json'))==case['pre_state_sha256']
        if arm=='C': result=execute_engine(suite,task,env,cid,wire,authority)
        else: result=execute_trajectory(suite=suite,user_task=task,injection_task=suite.get_injection_task_by_id(cid.split(':')[2]),
            initial_env=env,arm=arm,pipeline=build_pipeline(wire),rcc_gate=load_rcc_gate(ROOT/'rcc-v13'),case_id=cid,authority_admitted=authority)
        result['scope']=SCOPE
        (out/'cases'/(cid.replace(':','_')+'_'+arm+'.json')).write_text(json.dumps(result,sort_keys=True,ensure_ascii=False)+'\n')
        return result
    print(json.dumps({'run_directory':str(out),'trajectories':384,'model':MODEL_ID,'budget':budget.summary()}),flush=True)
    generated=[]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(execute,case,arm) for case in cases for arm in 'ABC']
        for f in as_completed(futures):
            generated.append(f.result())
            if len(generated)%16==0: print(json.dumps({'finished':len(generated),'total':384,'errors':sum(r['status']!='COMPLETED' for r in generated),'budget':budget.summary()}),flush=True)
    generated.sort(key=lambda r:(r['case_id'],r['arm']))
    output=out/'execution_records.jsonl';output.write_text('\n'.join(json.dumps(r,sort_keys=True,ensure_ascii=False) for r in generated)+'\n')
    lock={'record_count':len(generated),'records_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),'all_selection_barrier':True,'no_grade_based_per_row_selection':True}
    (out/'final-lock.json').write_text(json.dumps(lock,indent=2)+'\n')
    scores=[]
    for r in generated:
        score={'case_id':r['case_id'],'arm':r['arm'],'score_status':'NOT_SCORED_EXECUTION_ERROR'}
        if r['status']=='COMPLETED':
            parts=r['case_id'].split(':');pre=suite.environment_type.model_validate(r['pre_environment']);post=suite.environment_type.model_validate(r['post_environment']);trace=[FunctionCall.model_validate(x) for x in r['functions_stack_trace']]
            score.update(score_status='SCORED',utility=bool(suite._check_task_result(suite.get_user_task_by_id(parts[1]),r['model_output'],pre,post,trace)),injection_success=bool(suite._check_task_result(suite.get_injection_task_by_id(parts[2]),r['model_output'],pre,post,trace)))
        scores.append(score)
    summary={'scope':SCOPE,'model':MODEL_ID,'case_count':128,'record_count':len(generated),
        'execution_errors':sum(r['status']!='COMPLETED' for r in generated),'budget':budget.summary(),'arms':{}}
    for arm in 'ABC':
        selected=[s for s in scores if s['arm']==arm and s['score_status']=='SCORED']
        summary['arms'][arm]={'enrolled':128,'scored':len(selected),'utility':sum(s['utility'] for s in selected),'injection_success':sum(s['injection_success'] for s in selected)}
    (out/'native_scores.json').write_text(json.dumps(scores,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({'run_directory':str(out),'summary':summary},indent=2),flush=True)


if __name__=='__main__': main()
