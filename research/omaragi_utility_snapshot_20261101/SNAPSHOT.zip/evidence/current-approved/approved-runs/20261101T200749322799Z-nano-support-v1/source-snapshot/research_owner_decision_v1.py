"""Read the actual review decision; never accept a caller's approval boolean.

This is provenance for a disposable local research operator decision, not
cryptographic attestation of a human, bank, production issuer or secure host.
It confers no Native permission by itself and does not override legacy policy.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
from typing import Any,Mapping

ROOT=Path(__file__).resolve().parents[1]
YES='소유자로서 별도 승인 조건의 실험 허용'
NO='기존 권한 입력과 정책만 유지'
DATABASE=Path('/Users/lua/.codex/thread_history_1.sqlite')


def digest(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_review_reply(item_type:str,item:Mapping[str,Any],anchor:Mapping[str,Any])->str|None:
    """Only a complete actual user reply to this exact indexed question."""
    if item_type!='userMessage' or item.get('type')!='userMessage':return None
    content=item.get('content')
    if not isinstance(content,list) or len(content)!=1:return None
    matches=[]
    for entry in content:
        if not isinstance(entry,dict) or entry.get('type')!='text':continue
        # App transcript text is untrusted until its role, whole-message shape,
        # exact question identity and answer are all verified below.
        for value in [entry.get('text')]:
            if not isinstance(value,str):continue
            match=re.fullmatch(r'\s*<send_user_message_question_reply>\s*(\[.*\])\s*</send_user_message_question_reply>\s*',value,re.S)
            if not match:continue
            try:replies=json.loads(match.group(1))
            except (ValueError,TypeError):continue
            if not isinstance(replies,list) or len(replies)!=1:continue
            reply=replies[0]
            if not isinstance(reply,dict) or set(reply)!={'questionItemId','question','answer'}:continue
            try:identity=json.loads(reply['questionItemId'])
            except (ValueError,TypeError):continue
            if identity!=['request_user_input_async',anchor['question_id'],0]:continue
            if reply['question']!=anchor['question_title']:continue
            if reply['answer'] in (YES,NO):matches.append(reply['answer'])
    return matches[0] if len(matches)==1 else None


def is_scope_revocation(item:Mapping[str,Any],proposal_sha:str)->bool:
    content=item.get('content')
    if item.get('type')!='userMessage' or not isinstance(content,list) or len(content)!=1:return False
    entry=content[0]
    if not isinstance(entry,dict) or entry.get('type')!='text':return False
    text=entry.get('text','').strip()
    return text in {'실험 중단','실험 취소','승인 취소','stop experiment','cancel experiment',
                    'RESEARCH-AUTH-REVOKE '+proposal_sha}


def inspect_current_decision()->dict[str,Any]:
    anchor=json.loads((ROOT/'OWNER_QUESTION_ANCHOR.json').read_text())
    if digest(ROOT/'RESEARCH_APPROVAL_PROPOSAL.json')!=anchor['proposal_sha256']:
        raise RuntimeError('REVIEWED_PROPOSAL_CHANGED')
    if digest(ROOT/'OWNER_REVIEW_KO.md')!=anchor['review_document_sha256']:
        raise RuntimeError('REVIEW_DOCUMENT_CHANGED')
    thread=os.environ.get('CODEX_THREAD_ID')
    if not thread or thread!=anchor['thread_id']:raise RuntimeError('WRONG_REVIEW_THREAD')
    with sqlite3.connect(f'file:{DATABASE}?mode=ro',uri=True) as c:
        questions=c.execute('select item_json,rollout_ordinal from thread_items where thread_id=? and item_type=? and item_id=?',
                            (thread,'agentMessage',anchor['question_id'])).fetchall()
        if len(questions)!=1:raise RuntimeError('EXACT_REVIEW_QUESTION_REQUIRED')
        question=json.loads(questions[0][0])
        offered=question.get('questions',[{}])[0]
        if (questions[0][1]!=anchor['question_ordinal'] or offered.get('title')!=anchor['question_title']
                or offered.get('options')!=[YES,NO]):
            raise RuntimeError('QUESTION_ORIGIN_CHANGED')
        candidates=c.execute('select item_json,item_type,rollout_ordinal,created_at_ms from thread_items '
            'where thread_id=? and item_type=? and rollout_ordinal>? order by rollout_ordinal',
            (thread,'userMessage',anchor['question_ordinal'])).fetchall()
    received=[]
    for raw,kind,ordinal,created_ms in candidates:
        item=json.loads(raw);decision=parse_review_reply(kind,item,anchor)
        if decision:received.append({'answer':decision,'message_id':item.get('id'),
            'source_ordinal':ordinal,'created_at_ms':created_ms,
            'source_record_sha256':hashlib.sha256(raw.encode()).hexdigest()})
    latest=received[-1] if received else None
    revoked=[]
    if latest:
        for raw,kind,ordinal,created_ms in candidates:
            item=json.loads(raw)
            if ordinal>latest['source_ordinal'] and is_scope_revocation(item,anchor['proposal_sha256']):
                revoked.append({'message_id':item.get('id'),'source_ordinal':ordinal,'created_at_ms':created_ms,
                    'source_record_sha256':hashlib.sha256(raw.encode()).hexdigest()})
    return {'schema':'veritas.owner-review-origin.v1','proposal_sha256':anchor['proposal_sha256'],
        'owner_review_approved':bool(latest and latest['answer']==YES and not revoked),
        'status':('OWNER_REVOKED_NEW_CONDITION' if revoked else 'OWNER_DECISION_RECEIVED_NEW_POLICY_INTEGRATION_STILL_REQUIRED' if latest and latest['answer']==YES
                  else 'OWNER_DECLINED_NEW_CONDITION' if latest else 'PENDING_OWNER_DECISION'),
        'decision_source':latest,'revocation_source':revoked[-1] if revoked else None,'question_id':anchor['question_id'],
        'source_is_actual_user_reply_not_model_output':bool(latest),
        'legacy_policy_changed':False,'protected_execution_admitted':False,
        'date_authority_issued':False,'production_issuer_or_host_attestation':False,
        'external_api_call_started_by_this_reader':False}


if __name__=='__main__':
    result=inspect_current_decision()
    (ROOT/'OWNER_DECISION_STATUS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
