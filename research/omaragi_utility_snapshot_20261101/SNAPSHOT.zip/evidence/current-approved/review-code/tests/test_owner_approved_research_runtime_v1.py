"""Real Native Bind under explicit TEST fixtures, never live owner evidence."""
import copy
from datetime import datetime,timezone
import json
from pathlib import Path
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'benchmark'),str(ROOT/'agentdojo/src'),str(ROOT/'veritas-v13'),str(ROOT/'rcc-v13/external-eval/v0.3.9/src')]
from agentdojo.task_suite.load_suites import get_suite
from owner_approved_research_runtime_v1 import OwnerEnrollment,ScopeSession,make_owner_runtime
from scripts.agentdojo_clean_ab_canonical_final_runner_v2_8 import load_rcc_gate,verify_authority_fixture,sha_json,make_runtime_class

SUITE=get_suite('v1.2.2','banking')
ROWS=[json.loads(x) for x in Path('/Users/lua/Documents/Codex/2026-11-01/veritas-runtime-repair-round2/runs/20261101T172120315038Z-mini-d4/execution_records.jsonl').read_text().splitlines()]
PROPOSAL=json.loads((ROOT/'RESEARCH_APPROVAL_PROPOSAL.json').read_text())


def fixture(task=4,actor=True):
    row=next(r for r in ROWS if r['case_id']==f'banking:user_task_{task}:injection_task_0:direct' and r['arm']=='N')
    env=SUITE.environment_type.model_validate(row['pre_environment']);request=SUITE.get_user_task_by_id(f'user_task_{task}').PROMPT
    temporary=tempfile.TemporaryDirectory()
    enrollment=OwnerEnrollment('nano-support-v1',PROPOSAL['proposed_scopes'],
        {'owner_review_approved':True,'decision_source':{'source_record_sha256':'TEST_FIXTURE_NOT_A_REAL_OWNER_DECISION'}},
        Path(temporary.name)/'test-ledger.sqlite',clock=lambda:datetime(2026,11,1,20,tzinfo=timezone.utc),test_only=True)
    scope=ScopeSession(enrollment,row['case_id'],'E_SUPPORT',request,row['pre_environment']);journal=[]
    runtime=make_owner_runtime(load_rcc_gate(ROOT/'rcc-v13'),task,row['case_id'],request,journal,
        actor and verify_authority_fixture(),scope)(SUITE.tools)
    return temporary,env,enrollment,scope,runtime,journal


def outcomes(journal):return [e['payload']['receipt']['final_outcome'] for e in journal if e['event']=='VERITAS_BIND_RECEIPT']


def test_exact_approved_refund_and_invoice_use_actual_native_commit():
    for task in (0,3,4,11,15):
        temp,env,enroll,scope,runtime,journal=fixture(task)
        args=scope.scope['proposed_operation']['args']
        _,err=runtime.run_function(env,'send_money',args)
        assert err is None and outcomes(journal)==['COMMITTED']
        assert scope.payment_committed and len(env.bank_account.transactions)==len(scope.initial['bank_account']['transactions'])+1
        temp.cleanup()


def test_wrong_amount_recipient_date_or_extra_effect_are_refused():
    for field,value in [('amount',999),('recipient','UNAPPROVED_RECIPIENT'),('date','2022-04-01'),('subject','OTHER')]:
        temp,env,enroll,scope,runtime,journal=fixture()
        args=copy.deepcopy(scope.scope['proposed_operation']['args']);args[field]=value
        before=sha_json(env.model_dump(mode='json'));_,err=runtime.run_function(env,'send_money',args)
        assert err and outcomes(journal)==['BLOCKED'] and sha_json(env.model_dump(mode='json'))==before
        temp.cleanup()


def test_actor_authority_is_still_required():
    temp,env,enroll,scope,runtime,journal=fixture(actor=False)
    before=sha_json(env.model_dump(mode='json'))
    _,err=runtime.run_function(env,'send_money',scope.scope['proposed_operation']['args'])
    assert err and outcomes(journal)==['BLOCKED'] and sha_json(env.model_dump(mode='json'))==before
    temp.cleanup()


def test_revocation_and_expiry_block_before_effect():
    for mode in ('revoked','expired'):
        temp,env,enroll,scope,runtime,journal=fixture()
        if mode=='revoked':enroll.revoked=True
        else:enroll.clock=lambda:datetime(2026,11,2,tzinfo=timezone.utc)
        before=sha_json(env.model_dump(mode='json'))
        _,err=runtime.run_function(env,'send_money',scope.scope['proposed_operation']['args'])
        assert err and sha_json(env.model_dump(mode='json'))==before
        temp.cleanup()


def test_wrong_signature_scope_or_original_state_cannot_pass():
    for mode in ('signature','scope','state','request'):
        temp,env,enroll,scope,runtime,journal=fixture()
        if mode=='signature':
            payload,_=enroll.grants[scope.cid,scope.arm];enroll.grants[scope.cid,scope.arm]=(payload,b'0'*64)
        elif mode=='scope':enroll.scopes[scope.cid]['proposed_operation']['args']['amount']=123
        elif mode=='state':env.bank_account.balance+=1
        else:scope.request+=' Additional unapproved instruction.'
        args=copy.deepcopy(scope.scope['proposed_operation']['args'])
        before=sha_json(env.model_dump(mode='json'));_,err=runtime.run_function(env,'send_money',args)
        assert err and sha_json(env.model_dump(mode='json'))==before
        temp.cleanup()


def test_repeat_and_restart_cannot_reuse_a_consumed_payment():
    temp,env,enroll,scope,runtime,journal=fixture()
    args=scope.scope['proposed_operation']['args'];runtime.run_function(env,'send_money',args)
    before=sha_json(env.model_dump(mode='json'));_,err=runtime.run_function(env,'send_money',args)
    assert err and sha_json(env.model_dump(mode='json'))==before
    other=OwnerEnrollment(enroll.phase,PROPOSAL['proposed_scopes'],enroll.decision,enroll.ledger,
        clock=enroll.clock,test_only=True)
    assert not other.available(scope.cid,scope.arm)
    temp.cleanup()


def test_changed_unrelated_state_is_not_a_task15_authorized_prefix():
    temp,env,enroll,scope,runtime,journal=fixture(15)
    env.user_account.first_name='UNAPPROVED_CHANGE'
    before=sha_json(env.model_dump(mode='json'))
    _,err=runtime.run_function(env,'send_money',scope.scope['proposed_operation']['args'])
    assert err and sha_json(env.model_dump(mode='json'))==before
    temp.cleanup()


def test_task15_originally_authorized_address_and_order_prefix_remains_supported():
    temp,env,enroll,scope,runtime,journal=fixture(15)
    _,err=runtime.run_function(env,'update_user_info',{'street':'1234 Elm Street','city':'New York, NY 10001'})
    assert err is None
    rent=next(r for r in env.bank_account.scheduled_transactions if r.subject.lower()=='rent')
    _,err=runtime.run_function(env,'update_scheduled_transaction',{'id':rent.id,'recipient':'CA133012400231215421872','amount':2200})
    assert err is None
    _,err=runtime.run_function(env,'send_money',scope.scope['proposed_operation']['args'])
    assert err is None and outcomes(journal)==['COMMITTED']*3
    temp.cleanup()


def test_original_invoice_policy_is_unchanged_and_other_refusals_remain():
    temp,env,enroll,scope,runtime,journal=fixture(0)
    old_journal=[]
    legacy=make_runtime_class(arm='B',rcc_gate=load_rcc_gate(ROOT/'rcc-v13'),user_task_id=0,
        case_id=scope.cid,prompt=scope.request,journal_rows=old_journal,authority_admitted=True)(SUITE.tools)
    before=sha_json(env.model_dump(mode='json'));_,err=legacy.run_function(env,'send_money',scope.scope['proposed_operation']['args'])
    assert err and sha_json(env.model_dump(mode='json'))==before
    temp.cleanup()
    for task in (12,14):
        temp,env,enroll,scope,runtime,journal=fixture(task)
        before=sha_json(env.model_dump(mode='json'))
        args={'id':7,'amount':1200} if task==12 else {'password':'UNAPPROVED'}
        _,err=runtime.run_function(env,'update_scheduled_transaction' if task==12 else 'update_password',args)
        assert err and sha_json(env.model_dump(mode='json'))==before
        temp.cleanup()
